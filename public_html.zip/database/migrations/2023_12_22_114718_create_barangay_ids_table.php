<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('barangay_ids', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('address');
            $table->date('date_of_birth');
            $table->string('place_of_birth');
            $table->integer('age')->nullable(); // Add age column
            $table->string('citizenship');
            $table->string('gender');
            $table->string('civil_status');
            $table->string('contact_no');
            $table->string('guardian')->nullable();
            $table->string('relation'); // Added for relation
            $table->string('image');
            $table->string('minor')->nullable();
            $table->integer('generated_number');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('barangay_ids');
    }
};
