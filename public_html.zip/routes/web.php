<?php

use Illuminate\Foundation\Http\FormRequest;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\UserManagementController;
use App\Http\Controllers\BrgtanodController;
use App\Http\Controllers\ChristoperController;
use App\Http\Controllers\DanielController;
use App\Http\Controllers\GuecoController;
use App\Http\Controllers\ManalangController;
use App\Http\Controllers\CarlController;
use App\Http\Controllers\ErwinController;
use App\Http\Controllers\karenController;
use App\Http\Controllers\AbelController;
use App\Http\Controllers\DeleonController;
use App\Http\Controllers\GalangController;




use App\Http\Controllers\MpostController;
use App\Http\Controllers\GranadaController;
use App\Http\Controllers\DanielAgustinController;
use App\Http\Controllers\ChristinaController;
use App\Http\Controllers\ArvhieController;
use App\Http\Controllers\MacabantiController;
use App\Http\Controllers\AdrianoController;
use App\Http\Controllers\ManlapazController;




use App\Http\Controllers\BarangayClearanceController;
use App\Http\Controllers\BarangayClearanceIdController;

use App\Http\Controllers\CertificationController;
use App\Http\Controllers\AboutController;
use App\Http\Controllers\ContactUsFormController;
use App\Http\Livewire\Users;

use App\Http\Controllers\ResidenceController;
use App\Http\Controllers\NotificationController;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendVerificationMailer;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
// ----------------------------- Start Backlog-----------------------//
// Route::group(['middleware' => 'prevent-back-history'],function(){


Route::get('/', function () {
    return view('welcome');
});



Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';



 

// ----------------------------- LOGIN AND RESITER -----------------------//
Route::controller(AuthController::class)->group(function () {
    Route::get('register', 'register')->name('register');
    Route::post('register', 'registerSave')->name('register.save');
  
    Route::get('login', 'login')->name('login');
    Route::post('login', 'loginAction')->name('login.action');
  
    Route::get('logout', 'logout')->middleware('auth')->name('logout');
});

// ----------------------------- DASHBOARD -----------------------//
Route::middleware('auth')->group(function () {
    Route::get('dashboard', function () {
        return view('dashboard');
    })->name('dashboard');

// ----------------------------- PRODUCT -----------------------//
    Route::controller(ProductController::class)->prefix('products')->group(function () {
        Route::get('', 'index')->name('products');
        Route::get('create', 'create')->name('products.create');
        Route::post('store', 'store')->name('products.store');
        Route::get('show/{id}', 'show')->name('products.show');
        Route::get('edit/{id}', 'edit')->name('products.edit');
        Route::put('edit/{id}', 'update')->name('products.update');
        Route::delete('destroy/{id}', 'destroy')->name('products.destroy');
    });
 
    // Route::get('/profile', [App\Http\Controllers\AuthController::class, 'profile'])->name('profile');
});

// ----------------------------- CHRISTOPER POSTS -----------------------//
Route::get('/blog', [BlogController::class, 'index']);
Route::get('/detail/{id}', [BlogController::class, 'detail']);
Route::get('/data', [BlogController::class, 'data']);
Route::get('/blog/create', [BlogController::class, 'create'])->name('blog.create');
Route::post('/store', [BlogController::class, 'store']);
Route::get('/edit/{id}', [BlogController::class, 'edit']);
Route::post('/update/{id}', [BlogController::class, 'update']);
Route::post('/delete/{id}', [BlogController::class, 'delete']);


// // ----------------------------- Angelica POSTS -----------------------//
Route::get('/angelica', [MpostController::class, 'index']);
Route::get('/MagsinoDetail/{id}', [MpostController::class, 'MagsinoDetail']);
Route::get('/data2', [MpostController::class, 'data2']);
Route::get('/angelica/create', [MpostController::class, 'create'])->name('angelica.create');
Route::post('/store2', [MpostController::class, 'store2']);
Route::get('/edit2/{id}', [MpostController::class, 'edit2']);
Route::post('/update2/{id}', [MpostController::class, 'update2']);
Route::post('/delete2/{id}', [MpostController::class, 'delete2']);




// ----------------------------- GGG POSTS -----------------------//
Route::get('/ggg', [GranadaController::class, 'index']);
Route::get('/glennDetail/{id}', [GranadaController::class, 'glennDetail']);
Route::get('/data3', [GranadaController::class, 'data3']);
Route::get('/ggg/create', [GranadaController::class, 'create'])->name('ggg.create');
Route::post('/store3', [GranadaController::class, 'store3']);
Route::get('/edit3/{id}', [GranadaController::class, 'edit3']);
Route::post('/update3/{id}', [GranadaController::class, 'update3']);
Route::post('/delete3/{id}', [GranadaController::class, 'delete3']);

// ----------------------------- DANIEL POSTS -----------------------//
Route::get('/danielAgustin', [DanielAgustinController::class, 'index']);
Route::get('/agustinDetail/{id}', [DanielAgustinController::class, 'agustinDetail']);
Route::get('/data4', [DanielAgustinController::class, 'data4']);
Route::get('/danielAgustin/create', [DanielAgustinController::class, 'create'])->name('danielAgustin.create');
Route::post('/store4', [DanielAgustinController::class, 'store4']);
Route::get('/edit4/{id}', [DanielAgustinController::class, 'edit4']);
Route::post('/update4/{id}', [DanielAgustinController::class, 'update4']);
Route::post('/delete4/{id}', [DanielAgustinController::class, 'delete4']);

// ----------------------------- CHRISTINA POSTS -----------------------//
Route::get('/Christina', [ChristinaController::class, 'index']);
Route::get('/christinaDetail/{id}', [ChristinaController::class, 'christinaDetail']);
Route::get('/data5', [ChristinaController::class, 'data5']);
Route::get('/Christina/create', [ChristinaController::class, 'create'])->name('Christina.create');
Route::post('/store5', [ChristinaController::class, 'store5']);
Route::get('/edit5/{id}', [ChristinaController::class, 'edit5']);
Route::post('/update5/{id}', [ChristinaController::class, 'update5']);
Route::post('/delete5/{id}', [ChristinaController::class, 'delete5']);

// ----------------------------- CARL ARBIE POSTS -----------------------//
Route::get('/arvhie', [ArvhieController::class, 'index']);
Route::get('/arvhieDetail/{id}', [ArvhieController::class, 'arvhieDetail']);
Route::get('/data6', [ArvhieController::class, 'data6']);
Route::get('/arvhie/create', [ArvhieController::class, 'create'])->name('arvhie.create');
Route::post('/store6', [ArvhieController::class, 'store6']);
Route::get('/edit6/{id}', [ArvhieController::class, 'edit6']);
Route::post('/update6/{id}', [ArvhieController::class, 'update6']);
Route::post('/delete6/{id}', [ArvhieController::class, 'delete6']);

// ----------------------------- ERWIN MACABANTI POSTS -----------------------//
Route::get('/macabanti', [MacabantiController::class, 'index']);
Route::get('/macabantiDetail/{id}', [MacabantiController::class, 'macabantiDetail']);
Route::get('/data7', [MacabantiController::class, 'data7']);
Route::get('/macabanti/create', [MacabantiController::class, 'create'])->name('macabanti.create');
Route::post('/store7', [MacabantiController::class, 'store7']);
Route::get('/edit7/{id}', [MacabantiController::class, 'edit7']);
Route::post('/update7/{id}', [MacabantiController::class, 'update7']);
Route::post('/delete7/{id}', [MacabantiController::class, 'delete7']);

// ----------------------------- KAREN ADRIANO POSTS -----------------------//
Route::get('/adriano', [AdrianoController::class, 'index']);
Route::get('/adrianoDetail/{id}', [AdrianoController::class, 'adrianoDetail']);
Route::get('/data8', [AdrianoController::class, 'data8']);
Route::get('/adriano/create', [AdrianoController::class, 'create'])->name('adriano.create');
Route::post('/store8', [AdrianoController::class, 'store8']);
Route::get('/edit8/{id}', [AdrianoController::class, 'edit8']);
Route::post('/update8/{id}', [AdrianoController::class, 'update8']);
Route::post('/delete8/{id}', [AdrianoController::class, 'delete8']);

// ----------------------------- MANLAPAZ POSTS -----------------------//
Route::get('/manlapaz', [ManlapazController::class, 'index']);
Route::get('/abelleDetail/{id}', [ManlapazController::class, 'abelleDetail']);
Route::get('/data9', [ManlapazController::class, 'data9']);
Route::get('/manlapaz/create', [ManlapazController::class, 'create'])->name('manlapaz.create');
Route::post('/store9', [ManlapazController::class, 'store9']);
Route::get('/edit9/{id}', [ManlapazController::class, 'edit9']);
Route::post('/update9/{id}', [ManlapazController::class, 'update9']);
Route::post('/delete9/{id}', [ManlapazController::class, 'delete9']);


// ----------------------------- Danilo Deleon POSTS -----------------------//
Route::get('/deleon', [DeleonController::class, 'index']);
Route::get('/deleonDetail/{id}', [DeleonController::class, 'deleonDetail']);
Route::get('/data10', [DeleonController::class, 'data10']);
Route::get('/deleon/create', [DeleonController::class, 'create'])->name('deleon.create');
Route::post('/store10', [DeleonController::class, 'store10']);
Route::get('/edit10/{id}', [DeleonController::class, 'edit10']);
Route::post('/update10/{id}', [DeleonController::class, 'update10']);
Route::post('/delete10/{id}', [DeleonController::class, 'delete10']);

// ----------------------------- JOJO GALANG POSTS -----------------------//
Route::get('/galang', [GalangController::class, 'index']);
Route::get('/galangDetail/{id}', [GalangController::class, 'galangDetail']);
Route::get('/data11', [GalangController::class, 'data11']);
Route::get('/galang/create', [GalangController::class, 'create'])->name('galang.create');
Route::post('/store11', [GalangController::class, 'store11']);
Route::get('/edit11/{id}', [GalangController::class, 'edit11']);
Route::post('/update11/{id}', [GalangController::class, 'update11']);
Route::post('/delete11/{id}', [GalangController::class, 'delete11']);










// ----------------------------- User management -----------------------//
Route::controller(UserManagementController::class)->prefix('usermanagement')->group(function () {
    Route::get('', 'index')->name('usermanagement');
    Route::get('create', 'create')->name('usermanagement.create');
    Route::post('store', 'store')->name('usermanagement.store');
    Route::get('show/{id}', 'show')->name('usermanagement.show');
    Route::get('edit/{id}', 'edit')->name('usermanagement.edit');
    Route::put('edit/{id}', 'update')->name('usermanagement.update');
    Route::delete('destroy/{id}', 'destroy')->name('usermanagement.destroy');
});

Route::get('/get-notification-count', [NotificationController::class, 'getNotificationCount']);
Route::get('/notifications', [NotificationController::class, 'index'])->name('notifications.index');

// ----------------------------- ACTIVITY-LOGS -----------------------//
Route::get('activity/log', [UserManagementController::class, 'activity'])->name('activity/log');

// ----------------------------- Barangay Angelica posts -----------------------//
Route::controller(BrgtanodController::class)->prefix('brgtanod')->group(function () {
    Route::get('', 'index')->name('brgtanod');
    Route::get('create', 'create')->name('brgtanod.create');
    Route::post('store', 'store')->name('brgtanod.store');
    Route::get('show/{id}', 'show')->name('brgtanod.show');
    Route::get('edit/{id}', 'edit')->name('brgtanod.edit');
    Route::put('edit/{id}', 'update')->name('brgtanod.update');
    Route::delete('destroy/{id}', 'destroy')->name('brgtanod.destroy');
});

// ----------------------------- Barangay Christoper posts -----------------------//
Route::controller(ChristoperController::class)->prefix('christoper')->group(function () {
    Route::get('/christoper', [ChristoperController::class, 'index'])->name('christoper.index');
    Route::get('create', 'create')->name('christoper.create');
    Route::post('store', 'store')->name('christoper.store');
    Route::get('show/{id}', 'show')->name('christoper.show');
    Route::get('edit/{id}', 'edit')->name('christoper.edit');
    Route::put('edit/{id}', 'update')->name('christoper.update');
    Route::delete('destroy/{id}', 'destroy')->name('christoper.destroy');
});

// ----------------------------- Barangay daniel posts -----------------------//
Route::controller(DanielController::class)->prefix('daniel')->group(function () {
    Route::get('/daniel', [DanielController::class, 'index'])->name('daniel.index');
    Route::get('create', 'create')->name('daniel.create');
    Route::post('store', 'store')->name('daniel.store');
    Route::get('show/{id}', 'show')->name('daniel.show');
    Route::get('edit/{id}', 'edit')->name('daniel.edit');
    Route::put('edit/{id}', 'update')->name('daniel.update');
    Route::delete('destroy/{id}', 'destroy')->name('daniel.destroy');
});

// ----------------------------- Barangay Glen posts -----------------------//
Route::controller(GuecoController::class)->prefix('gueco')->group(function () {
    Route::get('/gueco', [GuecoController::class, 'index'])->name('gueco.index');
    Route::get('create', 'create')->name('gueco.create');
    Route::post('store', 'store')->name('gueco.store');
    Route::get('show/{id}', 'show')->name('gueco.show');
    Route::get('edit/{id}', 'edit')->name('gueco.edit');
    Route::put('edit/{id}', 'update')->name('gueco.update');
    Route::delete('destroy/{id}', 'destroy')->name('gueco.destroy');
});

// ----------------------------- Barangay Manalang posts -----------------------//
Route::controller(ManalangController::class)->prefix('manalang')->group(function () {
    Route::get('/manalang', [ManalangController::class, 'index'])->name('manalang.index');
    Route::get('create', 'create')->name('manalang.create');
    Route::post('store', 'store')->name('manalang.store');
    Route::get('show/{id}', 'show')->name('manalang.show');
    Route::get('edit/{id}', 'edit')->name('manalang.edit');
    Route::put('edit/{id}', 'update')->name('manalang.update');
    Route::delete('destroy/{id}', 'destroy')->name('manalang.destroy');
});

// ----------------------------- Barangay David posts -----------------------//
Route::controller(CarlController::class)->prefix('carl')->group(function () {
    Route::get('/carl', [CarlController::class, 'index'])->name('carl.index');
    Route::get('create', 'create')->name('carl.create');
    Route::post('store', 'store')->name('carl.store');
    Route::get('show/{id}', 'show')->name('carl.show');
    Route::get('edit/{id}', 'edit')->name('carl.edit');
    Route::put('edit/{id}', 'update')->name('carl.update');
    Route::delete('destroy/{id}', 'destroy')->name('carl.destroy');
});

// ----------------------------- Barangay Manalang posts -----------------------//
Route::controller(ErwinController::class)->prefix('erwin')->group(function () {
    Route::get('/erwin', [ErwinController::class, 'index'])->name('erwin.index');
    Route::get('create', 'create')->name('erwin.create');
    Route::post('store', 'store')->name('erwin.store');
    Route::get('show/{id}', 'show')->name('erwin.show');
    Route::get('edit/{id}', 'edit')->name('erwin.edit');
    Route::put('edit/{id}', 'update')->name('erwin.update');
    Route::delete('destroy/{id}', 'destroy')->name('erwin.destroy');
});

// ----------------------------- Barangay SK posts -----------------------//
Route::controller(KarenController::class)->prefix('karen')->group(function () {
    Route::get('/erwin', [KarenController::class, 'index'])->name('karen.index');
    Route::get('create', 'create')->name('karen.create');
    Route::post('store', 'store')->name('karen.store');
    Route::get('show/{id}', 'show')->name('karen.show');
    Route::get('edit/{id}', 'edit')->name('karen.edit');
    Route::put('edit/{id}', 'update')->name('karen.update');
    Route::delete('destroy/{id}', 'destroy')->name('karen.destroy');
});

// ----------------------------- Abel Official posts -----------------------//
Route::controller(AbelController::class)->prefix('abel')->group(function () {
    Route::get('/erwin', [AbelController::class, 'index'])->name('abel.index');
    Route::get('create', 'create')->name('abel.create');
    Route::post('store', 'store')->name('abel.store');
    Route::get('show/{id}', 'show')->name('abel.show');
    Route::get('edit/{id}', 'edit')->name('abel.edit');
    Route::put('edit/{id}', 'update')->name('abel.update');
    Route::delete('destroy/{id}', 'destroy')->name('abel.destroy');
    // Route::get('/detail/{id}', [AbelController::class, 'detail']);

});






// ----------------------------- Barangay clearance List -----------------------//
Route::get('/barangay_clearances', [BarangayClearanceController::class, 'index'])->name('barangay_clearances.index');
Route::get('/barangay_clearances/create', [BarangayClearanceController::class, 'create'])->name('barangay_clearances.create');
Route::get('/barangay_clearances/create1', [BarangayClearanceController::class, 'create1'])->name('barangay_clearances.create1');
Route::get('/barangay_clearances/create3', [BarangayClearanceController::class, 'create3'])->name('barangay_clearances.create3');
Route::get('/barangay_clearances/create4', [BarangayClearanceController::class, 'create4'])->name('barangay_clearances.create4');
Route::post('/barangay_clearances/store', [BarangayClearanceController::class, 'store'])->name('barangay_clearances.store');
Route::post('/barangay_clearances/store1', [BarangayClearanceController::class, 'store1'])->name('barangay_clearances.store1');
Route::post('/barangay_clearances/store3', [BarangayClearanceController::class, 'store3'])->name('barangay_clearances.store3');
Route::post('/barangay_clearances/store4', [BarangayClearanceController::class, 'store4'])->name('barangay_clearances.store4');

Route::get('/barangay_clearances/{id}/edit', [BarangayClearanceController::class, 'edit'])->name('barangay_clearances.edit');
Route::put('/barangay_clearances/{id}', [BarangayClearanceController::class, 'update'])->name('barangay_clearances.update');
Route::get('/barangay_clearances/show/{id}', [BarangayClearanceController::class, 'show'])->name('barangay_clearances.show');
Route::delete('/barangay_clearances/destroy/{id}', [BarangayClearanceController::class, 'destroy'])->name('barangay_clearances.destroy');
Route::post('/barangay_clearances/store', [BarangayClearanceController::class, 'store'])->name('barangay_clearances.store');
Route::get('/baranagayclearance', [BarangayClearanceController::class, 'create'])->name('baranagayclearance');

Route::get('/baranagayclearance/{id}/show', [BarangayClearanceController::class, 'show']);
Route::get('/baranagayclearance/{id}/show/pdf', [BarangayClearanceController::class, 'generatePdf'])->name('baranagayclearance.show.pdf');
Route::get('/baranagayclearance/{id}/show2/pdf2', [BarangayClearanceController::class, 'generatePdf2'])->name('baranagayclearance.show2.pdf2');




// ----------------------------- Barangay ID List -----------------------//
Route::get('/barangay-clearance-id', [BarangayClearanceIdController::class, 'index'])->name('barangay-clearance-id.index');
Route::get('/barangay-clearance-id/create', [BarangayClearanceIdController::class, 'create'])->name('barangay-clearance-id.create');
Route::get('/barangay-clearance-id/create1', [BarangayClearanceIdController::class, 'create1'])->name('barangay-clearance-id.create1');
Route::get('/barangay-clearance-id/create5', [BarangayClearanceIdController::class, 'create5'])->name('barangay-clearance-id.create5');
Route::get('/barangay-clearance-id/create7', [BarangayClearanceIdController::class, 'create7'])->name('barangay-clearance-id.create7');
Route::post('/barangay-clearance-id/store', 'BarangayClearanceIdController@store')->name('barangay-clearance-id.store');
Route::post('/barangay-clearance-id/store', [BarangayClearanceIdController::class, 'store'])->name('barangay-clearance-id.store');
Route::post('/barangay-clearance-id', [BarangayClearanceIdController::class, 'store1'])->name('clearance.store1');
Route::post('/barangay-clearance-id/store1', [BarangayClearanceIdController::class, 'store1'])->name('barangay-clearance-id.store1');
Route::post('/barangay-clearance-id/store5', [BarangayClearanceIdController::class, 'store5'])->name('barangay-clearance-id.store5');
Route::post('/barangay-clearance-id/store7', [BarangayClearanceIdController::class, 'store7'])->name('barangay-clearance-id.store7');
Route::get('/barangay-clearance-id/front/{id}', [BarangayClearanceIdController::class, 'frontShow'])->name('barangay-clearance-id.frontShow');
Route::get('/barangay-clearance-id/back/{id}', [BarangayClearanceIdController::class, 'backShow'])->name('barangay-clearance-id.backShow');
Route::get('/barangay-clearance-id/{id}/edit', [BarangayClearanceIdController::class, 'edit'])->name('barangay-clearance-id.edit');
Route::put('/barangay-clearance-id/{id}', [BarangayClearanceIdController::class, 'update'])->name('barangay-clearance-id.update');
Route::delete('/barangay-clearance-id/{id}', [BarangayClearanceIdController::class, 'destroy'])->name('barangay-clearance-id.destroy');
Route::post('/barangay-clearance-id/{id}/update', [BarangayClearanceIdController::class, 'update'])->name('barangay-clearance-id.update');
Route::get('/baranagayid', [BarangayClearanceIdController::class, 'create'])->name('baranagayid');
Route::get('/BarangayIdsController/{id}/show', [BarangayClearanceIdController::class, 'show']);
Route::get('/BarangayIdsController/{id}/show/pdf', [BarangayClearanceIdController::class, 'generatePdf'])->name('barangay-clearance-id.show.pdf');
Route::get('/backShow/{id}', [BarangayClearanceIdController::class, 'backShow'])->name('backShow');
Route::get('/generatePdf2/{id}', [BarangayClearanceIdController::class, 'generatePdf2'])->name('generatePdf2');



// ----------------------------- Barangay Indigency -----------------------//
Route::get('/certification', [CertificationController::class, 'index'])->name('certification.index');
Route::get('/certification/create', [CertificationController::class, 'create'])->name('certification.create');
Route::get('/certification/create1', [CertificationController::class, 'create1'])->name('certification.create1');
Route::get('/certification/create3', [CertificationController::class, 'create3'])->name('certification.create3');
Route::get('/certification/create4', [CertificationController::class, 'create4'])->name('certification.create4');

Route::post('/certification', [CertificationController::class, 'store'])->name('certification.store');
Route::post('/certification1', [CertificationController::class, 'store1'])->name('certification.store1');
Route::post('/certification3', [CertificationController::class, 'store3'])->name('certification.store3');
Route::post('/certification4', [CertificationController::class, 'store4'])->name('certification.store4');


Route::get('/certification/{id}/edit', [CertificationController::class, 'edit'])->name('certification.edit');
Route::put('/certification/{id}', [CertificationController::class, 'update'])->name('certification.update');
Route::get('/certification/show/{id}', [CertificationController::class, 'show'])->name('certification.show');
Route::delete('/certification/destroy/{id}', [CertificationController::class, 'destroy'])->name('certification.destroy');
Route::get('/certification/{id}/show', [CertificationController::class, 'show']);
Route::get('/certification/{id}/show/pdf', [CertificationController::class, 'generatePdf'])->name('certification.show.pdf');
Route::get('/certification/{id}/show2/pdf2', [CertificationController::class, 'generatePdf2'])->name('certification.show2.pdf2');


// ----------------------------- Barangay Resident -----------------------//
Route::get('/residence', [ResidenceController::class, 'index'])->name('residence.index');
Route::get('/residence/create', [ResidenceController::class, 'create'])->name('residence.create');
Route::get('/residence/create1', [ResidenceController::class, 'create1'])->name('residence.create1');
Route::get('/residence/create3', [ResidenceController::class, 'create3'])->name('residence.create3');
Route::get('/residence/create4', [ResidenceController::class, 'create4'])->name('residence.create4');

Route::post('/residence', [ResidenceController::class, 'store'])->name('residence.store');
Route::post('/residence/store1', [ResidenceController::class, 'store1'])->name('residence.store1');
Route::post('/residence/store4', [ResidenceController::class, 'store4'])->name('residence.store4');
Route::post('/residence/store5', [ResidenceController::class, 'store5'])->name('residence.store5');

Route::get('/residence/edit/{id}', [ResidenceController::class, 'edit'])->name('residence.edit');
Route::put('/residence/update/{id}', [ResidenceController::class, 'update'])->name('residence.update');
Route::get('/residence/show/{id}', [ResidenceController::class, 'show'])->name('residence.show');
Route::delete('/residence/destroy/{id}', [ResidenceController::class, 'destroy'])->name('residence.destroy');
Route::get('/residence/{id}/show', [ResidenceController::class, 'show']);
Route::get('/residence/{id}/show/pdf', [ResidenceController::class, 'generatePdf'])->name('residence.show.pdf');
Route::get('/residence/{id}/show2/pdf2', [ResidenceController::class, 'generatePdf2'])->name('residence.show2.pdf2');


// ----------------------------- Barangay Resident -----------------------//
Route::get('/residence', [ResidenceController::class, 'index'])->name('residence.index');
Route::get('/residence/create', [ResidenceController::class, 'create'])->name('residence.create');
Route::get('/residence/create1', [ResidenceController::class, 'create1'])->name('residence.create1');
Route::get('/residence/create3', [ResidenceController::class, 'create3'])->name('residence.create3');
Route::get('/residence/create4', [ResidenceController::class, 'create4'])->name('residence.create4');

Route::post('/residence', [ResidenceController::class, 'store'])->name('residence.store');
Route::post('store1', [ResidenceController::class, 'store1'])->name('residence.store1');
Route::post('store3', [ResidenceController::class, 'store3'])->name('residence.store3');
Route::post('store4', [ResidenceController::class, 'store4'])->name('residence.store4');

Route::get('/residence/edit/{id}', [ResidenceController::class, 'edit'])->name('residence.edit');
Route::put('/residence/update/{id}', [ResidenceController::class, 'update'])->name('residence.update');
Route::get('/residence/show/{id}', [ResidenceController::class, 'show'])->name('residence.show');
Route::delete('/residence/destroy/{id}', [ResidenceController::class, 'destroy'])->name('residence.destroy');
Route::get('/residence/{id}/show', [ResidenceController::class, 'show']);
Route::get('/residence/{id}/show/pdf', [ResidenceController::class, 'generatePdf'])->name('residence.show.pdf');


// ----------------------------- Post -----------------------//
Route::get('/agustin', [AboutController::class, 'create1'])->name('agustin');
Route::get('/macabanti', [AboutController::class, 'create2'])->name('macabanti');
Route::get('/glenn', [AboutController::class, 'create3'])->name('glenn');
Route::get('/dada', [AboutController::class, 'create4'])->name('dada');
Route::get('/christine', [AboutController::class, 'create5'])->name('christine');
Route::get('/arvhee', [AboutController::class, 'create6'])->name('arvhee');
Route::get('/magsino', [AboutController::class, 'create7'])->name('magsino');
Route::get('/about', [AboutController::class, 'create9'])->name('about');
Route::get('/adriano', [AboutController::class, 'create10'])->name('adriano');
Route::get('/abelle', [AboutController::class, 'create11'])->name('abelle');
Route::get('/deleon', [AboutController::class, 'create12'])->name('deleon');
Route::get('/galang', [AboutController::class, 'create13'])->name('galang');














// ----------------------------- OTP -----------------------//
Route::post('reset_password', [AuthController::class,'resetPassword']);
Route::get('forgot-password', function () {
    if(Session::has('current_user')){
        return redirect('dashboard');
    }else{
        return view('forgot-password');
    }
})->middleware('guest')->name('password.request');

Route::get('re-new-password', function (){

    return view('new-password')->with('failed','Invalid OTP code');
});
Route::post('/new-password', [AuthController::class,'findUserToChangePass']);
route::get('test-mail',function(){
    // Inside your function/method
    Session::put('reset_otp_code', random_int(000000,999999));
    Mail::to('jacinto011200@gmail.com')->send(new SendVerificationMailer());
});
Route::get('/new-password', [AuthController::class, 'newPassword'])->name('new-password');





// ----------------------------- Contact Us-----------------------//
Route::get('/contact', [ContactUsFormController::class, 'createForm']);
 
Route::post('/contact', [ContactUsFormController::class, 'ContactUsForm'])->name('contact.store');

Route::get('/index', [ContactUsFormController::class, 'index'])->name('contacts.index');
Route::get('/contacts/{id}', [ContactUsFormController::class, 'show'])->name('contact.show');
Route::delete('/contacts/{id}', [ContactUsFormController::class, 'destroy'])->name('contact.destroy');


// ----------------------------- End Of Route Back Log -----------------------//
// });