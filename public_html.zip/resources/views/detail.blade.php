@extends('layout')

@section('content')
<link rel="shortcut icon" href="{{ URL::to('admin_assets/img/title-logo/tabun.png') }}">
<link rel="shortcut icon" href="{{ URL::to('admin_assets/img/title-logo/tabun.png') }}" type="image/x-icon">
  
    {{-- Detail Artikel --}}
    <section id="detail">
        <div class="container col-xxl-8 d-flex justify-content-center py-5">

            <div class="card bg-white col-xxl-10 text-left border-0">
                <p class="mb-4">
                    <a href="/" class="text-decoration-none text-dark">Barang Tabun</a> / {{ $blogs->title }}
                </p>

                <h3 class="fw-bold mb-3">{{ $blogs->title }}</h3>
                <p class="mb-3">{{ $blogs->created_at->format('F j, Y') }}</p>

                <img src="{{ $blogs->image }}" class="img-fluid rounded-4 mb-3" alt="">

                {!! nl2br(e($blogs->desc)) !!}

            </div>

        </div>
    </section>
    {{-- Detail Artikel --}}
@endsection
