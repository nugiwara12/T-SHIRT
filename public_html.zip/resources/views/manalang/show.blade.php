@extends('layouts.app3')
  
@section('title', 'CRISTINA MANALANG DETAILED POST')
  
@section('contents')

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css">

<div class="container">
    <div class="row mb-3">
        <div class="col">
            <label for="title">Title</label>
            <input type="text" name="title" class="form-control form-control-user" placeholder="Enter Title" value="{{ $manalang->title }}" readonly>
        </div>
        <div class="col">
            <label for="image">Image</label>
                <img src="{{ asset($manalang->image) }}" alt="Image" style="max-width: 100%; height: auto;">
        </div>
    </div>

    <div class="row mb-3">
        <div class="col">
            <label for="description">Description</label>
            <textarea name="description" id="description" class="form-control form-control-user" readonly>{{ $manalang->description }}</textarea>
        </div>
    </div>


    <div class="row">
        <div class="d-grid">
            <!-- You can add a back button or any other actions here -->
            <a href="{{ route('manalang.index') }}" class="btn btn-secondary">Back</a>
        </div>
    </div>
</div>
<br><br><br>

<script>
    $(document).ready(function () {
        $('#description').summernote({
            toolbar: [],
            readOnly: true
        });
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>

@endsection