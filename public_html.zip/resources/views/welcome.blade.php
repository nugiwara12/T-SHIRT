@extends('layout')

@section('content')


  
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link rel="stylesheet" href="{{ URL::to('admin_assets/css/homepage.css') }}">
        <!-- <link rel="stylesheet" href="{{ URL::to('admin_assets/css/welcome.css') }}"> -->

        <link rel="shortcut icon" href="{{ URL::to('admin_assets/img/title-logo/tabun.png') }}">
        <link rel="shortcut icon" href="{{ URL::to('admin_assets/img/title-logo/tabun.png') }}" type="image/x-icon">
    </head>
    <body>
        <!-- Masthead-->
        <header class="masthead">
            <div class="container">
                <!-- <div class="masthead-subheading bg-black">Welcome To Our Barangay Tabun</div> -->
                <div class="masthead-heading text-uppercase bg-black">Welcome To Barangay Tabun</div>
                <a class="btn btn-primary btn-xl text-uppercase" href="#services">Tell Me More</a>
            </div>
        </header>
        <!-- Services-->
        <section class="page-section" id="services">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Application Forms</h2>
                    <h3 class="section-subheading text-muted">Barangays play a role in maintaining public safety and order. Barangay tanods (community volunteers) may assist in crime prevention, disaster response, and ensuring peace and order within the community.</h3>
                </div>
                <div class="row text-center">
                    <div class="col-md-4">
                        <a href="{{route('barangay_clearances.create1')}}"><span class="fa-stack fa-4x">
                            <svg xmlns="http://www.w3.org/2000/svg" width="180" height="140" fill="darkblue" class="bi bi-person-vcard" viewBox="0 0 16 16">
                                <path d="M5 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4m4-2.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5M9 8a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4A.5.5 0 0 1 9 8m1 2.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1-.5-.5"/>
                                <path d="M2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2zM1 4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H8.96q.04-.245.04-.5C9 10.567 7.21 9 5 9c-2.086 0-3.8 1.398-3.984 3.181A1 1 0 0 1 1 12z"/>
                            </svg>
                        </span></a>
                        <h4 class="my-3">Barangay Clearance</h4>
                        <!-- <p class="text-muted">Barangays often issue barangay clearances, which certify that a person is a resident of the barangay and is of good moral character. This document may be required for various purposes, such as employment, business permits, and other transactions.</p> -->
                    </div>
                    <div class="col-md-4">
                        <a href="{{route('certification.create1')}}"><span class="fa-stack fa-4x">
                            <svg xmlns="http://www.w3.org/2000/svg" width="180" height="140" fill="darkred" class="bi bi-person-vcard" viewBox="0 0 16 16">
                                <path d="M5 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4m4-2.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5M9 8a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4A.5.5 0 0 1 9 8m1 2.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1-.5-.5"/>
                                <path d="M2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2zM1 4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H8.96q.04-.245.04-.5C9 10.567 7.21 9 5 9c-2.086 0-3.8 1.398-3.984 3.181A1 1 0 0 1 1 12z"/>
                            </svg>
                        </span></a>
                        <h4 class="my-3">Barangay Indigency</h4>
                        <!-- <p class="text-muted">Barangays may provide basic health services such as health centers, vaccination programs, and community health education. They may also collaborate with local health authorities to address public health concerns.</p> -->
                    </div>
                    <div class="col-md-4">
                        <a href="{{route('residence.create1')}}"><span class="fa-stack fa-4x">
                        <svg xmlns="http://www.w3.org/2000/svg" width="180" height="140" fill="darkgreen" class="bi bi-person-vcard" viewBox="0 0 16 16">
                        <path d="M5 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4m4-2.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5M9 8a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4A.5.5 0 0 1 9 8m1 2.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1-.5-.5"/>
                        <path d="M2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2zM1 4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H8.96q.04-.245.04-.5C9 10.567 7.21 9 5 9c-2.086 0-3.8 1.398-3.984 3.181A1 1 0 0 1 1 12z"/>
                        </svg>
                        </span></a>
                        <h4 class="my-3">Barangay Residence</h4><br><br><br>
                    </div>
                    <div class="col-md-4">
                        <a href="{{ route('barangay-clearance-id.create1') }}"><span class="fa-stack fa-4x">
                            <svg xmlns="http://www.w3.org/2000/svg" width="180" height="140" fill="black" class="bi bi-person-vcard" viewBox="0 0 16 16">
                                <path d="M5 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4m4-2.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5M9 8a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4A.5.5 0 0 1 9 8m1 2.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1-.5-.5"/>
                                <path d="M2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2zM1 4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H8.96q.04-.245.04-.5C9 10.567 7.21 9 5 9c-2.086 0-3.8 1.398-3.984 3.181A1 1 0 0 1 1 12z"/>
                            </svg>
                        </span></a>
                        <h4 class="my-3">Barangay ID</h4>
                        <!-- <p class="text-muted">Barangays may provide basic health services such as health centers, vaccination programs, and community health education. They may also collaborate with local health authorities to address public health concerns.</p> -->
                    </div>
                </div>
            </div>
        </section>  



                <!-- Minor Services-->
            <section class="page-section" id="services" style="background-color: lightgray;">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Minor Application Forms</h2>
                    <h3 class="section-subheading text-muted">Barangays play a role in maintaining public safety and order. Barangay tanods (community volunteers) may assist in crime prevention, disaster response, and ensuring peace and order within the community.</h3>
                </div>
                <div class="row text-center">
                    <div class="col-md-4">
                        <a href="{{ route('barangay_clearances.create4') }}"><span class="fa-stack fa-4x">
                            <svg xmlns="http://www.w3.org/2000/svg" width="180" height="140" fill="darkblue" class="bi bi-person-vcard" viewBox="0 0 16 16">
                                <path d="M5 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4m4-2.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5M9 8a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4A.5.5 0 0 1 9 8m1 2.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1-.5-.5"/>
                                <path d="M2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2zM1 4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H8.96q.04-.245.04-.5C9 10.567 7.21 9 5 9c-2.086 0-3.8 1.398-3.984 3.181A1 1 0 0 1 1 12z"/>
                            </svg>
                        </span></a>
                        <h4 class="my-3">Barangay Clearance</h4>
                        <!-- <p class="text-muted">Barangays often issue barangay clearances, which certify that a person is a resident of the barangay and is of good moral character. This document may be required for various purposes, such as employment, business permits, and other transactions.</p> -->
                    </div>
                    <div class="col-md-4">
                        <a href="{{ route('certification.create4')}}"><span class="fa-stack fa-4x">
                            <svg xmlns="http://www.w3.org/2000/svg" width="180" height="140" fill="darkred" class="bi bi-person-vcard" viewBox="0 0 16 16">
                                <path d="M5 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4m4-2.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5M9 8a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4A.5.5 0 0 1 9 8m1 2.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1-.5-.5"/>
                                <path d="M2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2zM1 4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H8.96q.04-.245.04-.5C9 10.567 7.21 9 5 9c-2.086 0-3.8 1.398-3.984 3.181A1 1 0 0 1 1 12z"/>
                            </svg>
                        </span></a>
                        <h4 class="my-3">Barangay Indigency</h4>
                        <!-- <p class="text-muted">Barangays may provide basic health services such as health centers, vaccination programs, and community health education. They may also collaborate with local health authorities to address public health concerns.</p> -->
                    </div>
                    <div class="col-md-4">
                        <a href="{{ route('residence.create4') }}"><span class="fa-stack fa-4x">
                        <svg xmlns="http://www.w3.org/2000/svg" width="180" height="140" fill="darkgreen" class="bi bi-person-vcard" viewBox="0 0 16 16">
                        <path d="M5 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4m4-2.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5M9 8a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4A.5.5 0 0 1 9 8m1 2.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1-.5-.5"/>
                        <path d="M2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2zM1 4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H8.96q.04-.245.04-.5C9 10.567 7.21 9 5 9c-2.086 0-3.8 1.398-3.984 3.181A1 1 0 0 1 1 12z"/>
                        </svg>
                        </span></a>
                        <h4 class="my-3">Barangay Residence</h4><br><br><br>
                    </div>
                    <div class="col-md-4">
                        <a href="{{ route('barangay-clearance-id.create7') }}"><span class="fa-stack fa-4x">
                            <svg xmlns="http://www.w3.org/2000/svg" width="180" height="140" fill="black" class="bi bi-person-vcard" viewBox="0 0 16 16">
                                <path d="M5 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4m4-2.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5M9 8a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4A.5.5 0 0 1 9 8m1 2.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1-.5-.5"/>
                                <path d="M2 2a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2zM1 4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H8.96q.04-.245.04-.5C9 10.567 7.21 9 5 9c-2.086 0-3.8 1.398-3.984 3.181A1 1 0 0 1 1 12z"/>
                            </svg>
                        </span></a>
                        <h4 class="my-3">Barangay ID</h4>
                        <!-- <p class="text-muted">Barangays may provide basic health services such as health centers, vaccination programs, and community health education. They may also collaborate with local health authorities to address public health concerns.</p> -->
                    </div>
                </div>
            </div>
        </section> 



        
       <!-- About-->
       <!-- <section class="page-section" id="about">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">About</h2>
                    <h3 class="section-subheading text-muted">Barangay Tabun</h3>
                </div>
                <ul class="timeline">
                    <li>
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="admin_assets/img/bgy-ID-img/tabun.png" alt="..." /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>Barangay Tabun</h4>
                                <h4 class="subheading">Services</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">Barangay Tabun in Mabalacat City, Pampanga, offers a range of services to improve the quality of life for its residents. It prioritizes public safety, healthcare, education, and community empowerment through its dedicated police force, well-equipped health center, and support for local schools. The barangay also promotes cultural and recreational activities, and its open communication channels foster a sense of community and unity.</p></div>
                        </div>
                    </li>
                    <li class="timeline-inverted">
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="admin_assets/img/bgy-ID-img/tabun.png" alt="..." /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>Barangay Tabun</h4>
                                <h4 class="subheading">Mission</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt ut voluptatum eius sapiente, totam reiciendis temporibus qui quibusdam, recusandae sit vero unde, sed, incidunt et ea quo dolore laudantium consectetur!</p></div>
                        </div>
                    </li>
                    <li>
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="admin_assets/img/bgy-ID-img/tabun.png" alt="..." /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>Barangay Tabun</h4>
                                <h4 class="subheading">Vision</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt ut voluptatum eius sapiente, totam reiciendis temporibus qui quibusdam, recusandae sit vero unde, sed, incidunt et ea quo dolore laudantium consectetur!</p></div>
                        </div>
                    </li>
                    <li class="timeline-inverted">
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="admin_assets/img/bgy-ID-img/tabun.png" alt="..." /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>Barangay Tabun</h4>
                                <h4 class="subheading">Projects</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">Barangay Tabun in Mabalacat City, Pampanga, is transforming its residents through various community projects. The Health and Wellness Center promotes community health, while the Sustainable Livelihood Program empowers residents economically. Education is a top priority, with investments in infrastructure and innovative teaching methods. The Green Initiative integrates environmental stewardship, while the Sports and Recreation Complex promotes leisure and community bonding. Community engagement projects foster inclusivity and communication, paving the way for a brighter future.</p></div>
                        </div>
                    </li>
                    <li class="timeline-inverted">
                        <div class="timeline-image">
                            <h4 style="color: black">
                                Be Part
                                <br />
                                Of Our
                                <br />
                                Story!
                            </h4>
                        </div>
                    </li>
                </ul>
            </div>
        </section>
  -->
        <!-- Team-->
        <section class="page-section bg-light" id="team">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Barangay Council</h2>
                    <h3 class="section-subheading text-muted">"Serving with unity, leading with community."</h3>
                </div>
                <div class="row">
                    <div class="col-lg-4">
                        <div class="team-member">
                            <img class="mx-auto rounded-circle" src="admin_assets/img/kagawad/captain.jpg" alt="..." />
                            <h4>Hon. DANILO G. DE LEON</h4>
                            <p class="text-muted">Punong Barangay</p>
                            <!-- <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Twitter Profile"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Facebook Profile"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker LinkedIn Profile"><i class="fab fa-linkedin-in"></i></a> -->
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="team-member">
                        <img class="mx-auto rounded-circle" src="admin_assets/img/kagawad/kagawad (3).jpg" alt="..." />
                            <h4>Hon. ANGELICA C. MAGSINO</h4>
                            <p class="text-muted">Barangay Kagawad</p>
                            <!-- <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Twitter Profile"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Facebook Profile"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker LinkedIn Profile"><i class="fab fa-linkedin-in"></i></a> -->
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="team-member">
                        <img class="mx-auto rounded-circle" src="admin_assets/img/kagawad/kagawad (2).jpg" alt="..." />
                            <h4>Hon. CHRISTOPHER O. DE LEON</h4>
                            <p class="text-muted">Barangay Kagawad</p>
                            <!-- <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Diana Petersen Twitter Profile"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Diana Petersen Facebook Profile"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Diana Petersen LinkedIn Profile"><i class="fab fa-linkedin-in"></i></a> -->
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="team-member">
                        <img class="mx-auto rounded-circle" src="admin_assets/img/kagawad/kagawad (1).jpg" alt="..." />
                            <h4>Hon. GLEN G. GUECO</h4>
                            <p class="text-muted">Barangay Kagawad</p>
                            <!-- <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Twitter Profile"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Facebook Profile"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker LinkedIn Profile"><i class="fab fa-linkedin-in"></i></a> -->
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="team-member">
                        <img class="mx-auto rounded-circle" src="admin_assets/img/kagawad/kagawad (4).jpg" alt="..." />
                            <h4>Hon. DANIEL ROWEN S. AGUSTIN</h4>
                            <p class="text-muted">Barangay Kagawad</p>
                            <!-- <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Twitter Profile"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Facebook Profile"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker LinkedIn Profile"><i class="fab fa-linkedin-in"></i></a> -->
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="team-member">
                        <img class="mx-auto rounded-circle" src="admin_assets/img/kagawad/kagawad (8).jpg" alt="..." />
                            <h4>Hon. CRISTINA R. MANALANG</h4>
                            <p class="text-muted">Kagawad</p>
                            <!-- <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Twitter Profile"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Facebook Profile"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker LinkedIn Profile"><i class="fab fa-linkedin-in"></i></a> -->
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="team-member">
                        <img class="mx-auto rounded-circle" src="admin_assets/img/kagawad/kagawad (10).jpg" alt="..." />
                            <h4>Hon. CARL ARBIE G. DAVID</h4>
                            <p class="text-muted">Kagawad</p>
                            <!-- <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Twitter Profile"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Facebook Profile"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker LinkedIn Profile"><i class="fab fa-linkedin-in"></i></a> -->
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="team-member">
                        <img class="mx-auto rounded-circle" src="admin_assets/img/kagawad/kagawad (5).jpg" alt="..." />
                            <h4>Hon. ERWIN D. MACABANTI</h4>
                            <p class="text-muted">Kagawad</p>
                            <!-- <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Twitter Profile"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Facebook Profile"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker LinkedIn Profile"><i class="fab fa-linkedin-in"></i></a> -->
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="team-member">
                        <img class="mx-auto rounded-circle" src="admin_assets/img/kagawad/kagawad (11).jpg" alt="..." />
                            <h4>Hon. KAREN G. ADRIANO </h4>
                            <p class="text-muted">Sangguniang Kabataan</p>
                            <!-- <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Twitter Profile"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Facebook Profile"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker LinkedIn Profile"><i class="fab fa-linkedin-in"></i></a> -->
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="team-member">
                        <img class="mx-auto rounded-circle" src="admin_assets/img/kagawad/kagawad (6).jpg" alt="..." />
                            <h4>JOJO G. GALANG</h4>
                            <p class="text-muted">Secretary</p>
                            <!-- <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Twitter Profile"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Facebook Profile"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker LinkedIn Profile"><i class="fab fa-linkedin-in"></i></a> -->
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="team-member">
                            <img class="mx-auto rounded-circle" src="admin_assets/img/kagawad/kagawad (7).jpg" alt="..." />
                            <h4>ABEL C. MANLAPAZ</h4>
                            <p class="text-muted">Treasurer</p>
                            <!-- <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Twitter Profile"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker Facebook Profile"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Larry Parker LinkedIn Profile"><i class="fab fa-linkedin-in"></i></a> -->
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 mx-auto text-center"><p class="large text-muted">"Teamwork is the ability to work together toward a common vision. The ability to direct individual accomplishments toward organizational objectives. It is the fuel that allows common people to attain uncommon results."</p></div>
                </div>
            </div>
        </section>
        

       <!-- Footer-->

       <footer class="footer py-4">
            <div class="container">
                <div class="row align-items-center">
                <div class="col-lg-4 text-lg-start">Copyright Sarmiento / Mercado; Barangay Tabun</div>
                    <div class="col-lg-4 my-3 my-lg-0">
                        <!-- <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Twitter"><i class="fab fa-twitter"></i></a> -->
                        <a class="btn btn-dark btn-social mx-2" href="https://www.facebook.com/profile.php?id=61556005325787" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-dark btn-social mx-2" href="https://mail.google.com/mail/u/0/#inbox" aria-label="Email"><i class="fas fa-envelope"></i></a>
                        <!-- <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a> -->
                    </div>
                    <div class="col-lg-4 text-lg-end">
                        <a class="link-dark text-decoration-none me-3" href="https://mail.google.com/mail/u/0/#inbox">barangaytabunmabalacat@gmail.com</a>
                    </div>
                </div>
            </div>
        </footer>


        <!-- Portfolio Modals-->
        <!-- Portfolio item 1 modal popup-->
        
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <!-- Core theme JS-->
        <script src="{{asset('admin_assets/js/scripts.js')}}"></script>
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>

        {{-- Navbar --}}

        @yield('content')

        {{-- JQUERY --}}
        <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
            crossorigin="anonymous"></script>

        {{-- Summernote JS --}}
        <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.20/summernote-bs5.min.js"></script>
        <script>
            $(document).ready(function() {
                $('#summernote').summernote({
                    height: 300,
                });
            });
        </script>


        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous">
        </script>

        @yield('scripts')
    </body>
</html>


    
@endsection
