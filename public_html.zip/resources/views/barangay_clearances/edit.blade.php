@extends('layouts.app3')
  
@section('title', 'Edit Barangay Clearance')
  
@section('contents')
<link rel="stylesheet" href="{{URL::to('admin_assets/css/brgy-clearance-edit.css')}}">

<form action="{{ route('barangay_clearances.update', $barangay_clearances->id) }}" method="POST">
    @csrf
    @method('PUT')

    <label for="parent">Parent Name:</label>
    <input class="form-control" type="text" name="parent" value="{{ old('parent', $barangay_clearances->parent) }}" required>

    <label for="name">Name:</label>
    <input type="text" name="name" value="{{ old('name', $barangay_clearances->name) }}" required>
    <br>

    <label for="address">Address:</label>
    <input type="text" name="address" value="{{ old('address', $barangay_clearances->address) }}" required>
    <br>

    <label for="reason">Purpose to use:</label>
    <textarea name="reason" required>{{ old('reason', $barangay_clearances->reason) }}</textarea>

    <label for="age">Age:</label>
    <input class="form-control" type="number" name="age" value="{{ old('age', $barangay_clearances->age) }}" required min="1" max="200" pattern="[0-9]+">

    <br>
    <button type="submit">Update</button>
</form>


@endsection
