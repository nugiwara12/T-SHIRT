@extends('layouts.app3')
  
@section('title', 'Show Barangay Clearance')
  
@section('contents')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="{{URL::to('admin_assets/css/brgy-clearance-show.css')}}">
    <link rel="stylesheet" href="{{ URL::to('admin_assets/css/brgy-clearanceshow.css') }}">
    <title>Barangay Clearance</title>
</head>
<body>

<div class="certification">
<div class="header-left">
            <img class="left-logo" src="{{URL::to('admin_assets/img/bgy-ID-img/balacat.png')}}" alt="Left Logo">
            <img class="profile-picture" src="{{URL::to('admin_assets/img/bgy-ID-img/tabun.png')}}" alt="Profile Picture">
        </div>
    <div class="barangay">
        <h1 class="header-title1">Republic of the Philippines</h1>
        <h2 class="header-title2">Barangay Tabun</h2>
        <h3 class="header-title3">Mabalacat City</h3>
    </div>

    <div class="header">
        <h2 class="spaced-element">BARANAGAY CLEARANCE</h2>
        <h3 class="header-tag">To Whom It May Concern:</h3>
    </div><br>
    
        <div class="clearance">
        <!-- Use $barangay_clearance instead of $barangay_clearances -->
        <p>This is to certify that <span class="name">{{ $barangay_clearance->name }}</span>, with residence and postal address at <span class="address">{{ $barangay_clearance->address }}</span>, Barangay Tabun, Mabalacat City has no derogatory record filed in our Barangay Office.</p><br>
        <p>The above-named individual, who is a bonafide resident of this barangay, is a person of good moral character, peace-loving, and a civic-minded citizen.</p><br>
        <p>This certification/clearance is hereby issued in connection with the subject's application for <span class="reason">{{ $barangay_clearance->reason }}</span> and for whatever legal purpose it may serve him/her best and is valid for six (6) months from the date issued.</p>
    </div><br><br>

    <div class="footer-design">
        <p class="dates-text">Given this {{ $barangay_clearance->created_at->format('l, F j, Y') }}.</p>______________________________
        <p class="Head-class">DANILO G. DE LEON</p>
        <p class="Head-class-1">Punong Barangay</p>
        <p class="class-footer">Specimen Signature of Applicant:</p><br>
        <p class="class-footer">CTC No. ____________________</p>
        <p class="class-footer">Issued at. ____________________</p>
        <p class="class-footer">Issued on. ____________________</p>
    </div>
</div>

</body>
</html>
    <a class="back-button" href="{{ route('barangay_clearances.index') }}">Back to List</a>

    <a href="{{ route('baranagayclearance.show.pdf', ['id' => $barangay_clearance->id]) }}" class="btn btn-primary" target="_blank">Generate PDF</a>

@endsection
