@extends('layouts.app3')
  
@section('title', 'Create Minor Barangay Clearance')
  
@section('contents')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Baranagay Tabun</title>

    <link rel="shortcut icon" href="{{ URL::to('admin_assets/img/title-logo/tabun.png') }}">
    <link rel="shortcut icon" href="{{ URL::to('admin_assets/img/title-logo/tabun.png') }}" type="image/x-icon">
  
    <link rel="stylesheet" href="{{URL::to('admin_assets/css/brgy-clearance-create1.css')}}">
</head>
<body>


    <form action="{{ route('barangay_clearances.store3') }}" method="POST" enctype="multipart/form-data">
        
        @if(Session::has('success'))
            <div class="custom-box">
                <div class="alert alert-success" role="alert">
                    {{ Session::get('success') }}
                </div>
            </div>
        @endif
        
        @csrf
        <h1>Barangay Clearance</h1>
        <label for="parent">Parent Name:</label>
        <input class="form-control" type="text" name="parent" id="parent" name="parent" value="{{ old('parent') }}" required>
        <br>
        <label for="name">Name of Child:</label>
        <input class="form-control" type="text" name="name" id="name" name="name" value="{{ old('name') }}" required>
        <br>
        <label for="address">Address:</label>
        <input class="form-control" type="text" name="address" id="address" name="address" value="{{ old('address') }}" required>
        <br>
        <label for="reason">Purpose to use:</label>
        <textarea class="form-control" name="reason" id="reason" required>{{ old('reason') }}</textarea>
        <br>

        <label for="minor">Select Minor:</label>
        <select class="form-control" name="minor" id="minor" required>
            <option value="minor" @if(old('minor') == 'minor') selected @endif>Minor</option>
        </select>
        <br><br>

        <div class="mb-3">
        <label for="legal_age">Age:</label>
        <input class="form-control" type="number" id="age" name="age" value="{{ old('age') }}" required min="1" max="17" pattern="[0-9]+">
        @error('age')
            <span style="color: red;">{{ $message }}</span>
        @enderror
        </div>


        <label for="generated_number">Referal Code:</label>
            <input class="form-control" type="text" id="generated_number" name="generated_number" readonly>
            @error('generated_number')
                <span style="color: red;">{{ $message }}</span><br><br>
            @enderror

        <button type="button" onclick="generateNumber()">Generate Number</button><br><br>
        

        <button class="botton-submite" type="submit">Submit</button>
    </form>

</body>
</html>


<script>
    function generateNumber() {
    const generatedNumberInput = document.getElementById('generated_number');

    // Generate a random number or use your logic to generate one
    const randomNumber = Math.floor(Math.random() * 100000) + 1;

    // Fill the generated number into the input field
    generatedNumberInput.value = randomNumber;
}
</script>
@endsection

