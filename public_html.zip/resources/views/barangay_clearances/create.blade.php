@extends('layouts.app3')
  
@section('title', 'Create Barangay Clearance')
  
@section('contents')
<link rel="stylesheet" href="{{URL::to('admin_assets/css/brgy-clearance-create.css')}}">

<form action="{{ route('barangay_clearances.store') }}" method="POST" enctype="multipart/form-data">
        
        @if(Session::has('success'))
            <div class="custom-box">
                <div class="alert alert-success" role="alert">
                    {{ Session::get('success') }}
                </div>
            </div>
        @endif
        
        @csrf
        <h1>Barangay Clearance</h1>
        <label for="parent">Parent Name:</label>
        <input class="form-control" type="text" name="parent" id="parent" name="parent" value="{{ old('parent') }}" required>
        <br>
        <label for="name">Your Name</label>
        <input class="form-control" type="text" name="name" id="name" name="name" value="{{ old('name') }}" required>
        <br>
        <label for="address">Address:</label>
        <input class="form-control" type="text" name="address" id="address" name="address" value="{{ old('address') }}" required>
        <br>
        <label for="reason">Purpose to use:</label>
        <textarea class="form-control" name="reason" id="reason" required>{{ old('reason') }}</textarea>
        <br>

        <label for="age">Age:</label>
        <input class="form-control" type="number" id="age" name="age" value="{{ old('age') }}" required min="18" max="200" pattern="[0-9]+">


        <!-- <label for="minor">Select Legal Age:</label>
        <select class="form-control" name="minor" id="minor" required>
            <option value="minor" @if(old('minor') == 'minor') selected @endif>legal Age</option>
        </select>
        <br><br> -->


        <label for="generated_number">Referal Code:</label>
            <input class="form-control" type="text" id="generated_number" name="generated_number" readonly>
            @error('generated_number')
                <span style="color: red;">{{ $message }}</span><br><br>
            @enderror

        <button type="button" onclick="generateNumber()">Generate Number</button><br><br>
        

        <button class="botton-submite" type="submit">Submit</button>
    </form>


<script>
    function generateNumber() {
    const generatedNumberInput = document.getElementById('generated_number');

    // Generate a random number or use your logic to generate one
    const randomNumber = Math.floor(Math.random() * 100000) + 1;

    // Fill the generated number into the input field
    generatedNumberInput.value = randomNumber;
    }
</script>
@endsection
