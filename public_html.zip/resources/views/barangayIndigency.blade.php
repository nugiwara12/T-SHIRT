@extends('layout')

@section('content')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Baranagay Tabun</title>

    <link rel="shortcut icon" href="{{ URL::to('admin_assets/img/title-logo/tabun.png') }}">
    <link rel="shortcut icon" href="{{ URL::to('admin_assets/img/title-logo/tabun.png') }}" type="image/x-icon">
    <link rel="stylesheet" href="{{URL::to('admin_assets/css/indegency-create1.css')}}">
<body>
    
@if(Session::has('success'))
        <div class="alert alert-success" role="alert">
            {{ Session::get('success') }}
        </div>
    @endif

    <div class="certification">
        <!-- Your existing content -->

        <!-- Form section -->
        <div class="certification">
        <!-- Your existing content -->

        <!-- Form section -->
        <form action="{{ route('certification.store1') }}" method="POST">
            @csrf

            <label for="mother_name">Parent Name:</label>
            <input type="text" id="mother_name" name="mother_name" value="{{ old('mother_name') }}" required>
            @error('mother_name')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <label for="address">Address:</label>
            <input type="text" id="address" name="address" value="{{ old('address') }}" required>
            @error('address')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <label for="purpose">Purpose:</label>
            <input type="text" id="purpose" name="purpose" value="{{ old('purpose') }}" required>
            @error('purpose')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <label for="your_name">Your Name:</label>
            <input type="text" id="your_name" name="your_name" value="{{ old('your_name') }}" required>
            @error('your_name')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <label for="date">Date:</label>
            <input type="date" id="date" name="date" value="{{ old('date') }}" required>
            @error('date')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <input class="submited-botton" type="submit" value="Submit">
        </form>
    </div>


</body>

</html>


@endsection