@extends('layouts.app3')
  
@section('title', 'KAGAWAD CHRISTINA MANALANG RECORD POST')
  
@section('contents')
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="shortcut icon" href="{{ URL::to('admin_assets/img/title-logo/tabun.png') }}">
<link rel="shortcut icon" href="{{ URL::to('admin_assets/img/title-logo/tabun.png') }}" type="image/x-icon">
  

    <div class="container col-xxl-10 py-10">
        <div class="card bg-white p-4 shadow rounded-4 border-0">

            <div class="d-flex justify-content-between mb-4">
                <div>
                    <h4>Data Artikel</h4>
                </div>
                <div>
                    <a href="{{ route('Christina.create')}}" class="btn btn-primary" class="btn btn-primary" data-placement="top" title="Create Artikel">Create Artikel</a>
                </div>
            </div>

            {{-- Pesan Sukses di Simpan dan di Update --}}
            @if (session()->has('success'))
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>Informasi</strong> {{ session('success') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            @endif
            {{-- Pesan Sukses di Simpan dan di Update --}}

            <div class="table-responsive">
                <table class="table table-hover" id="example">
                    <thead class="table-primary">
                        <tr>
                            <th>NO</th>
                            <th>Title</th>
                            <th>Image</th>
                            <th>action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php
                            $no = 1;
                        @endphp
                        @foreach ($christina as $rs)
                            <tr>
                                <td>{{ $no++ }}</td>
                                <td>{{ $rs->title }}</td>
                                <td>
                                    <img src="{{ asset($rs->image) }}" height="100" alt="">
                                </td>

                                <td>
                                    <a href="/edit5/{{ $rs->id }}" class="btn btn-success" data-toggle="tooltip" data-placement="top" title="Edit">Edit</a>
                                    <form action="/delete5/{{ $rs->id }}" method="POST" class="d-inline">
                                        @csrf
                                        <button class="btn btn-danger btn-sm"
                                            onclick="return confirm('Are you sure ?')" data-toggle="tooltip" data-placement="top" title="Delete">
                                            Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>


    <footer>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>
    <script>
         $(document).ready(function() {
            $('#example').DataTable( {
                // dom: 'Bfrtip',
                // buttons: [
                //     'print',
                //     'excel'
                // ]
            } );
        } );
    </script>

    <!-- Include DataTables Buttons extension CSS and JS -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.1.1/css/buttons.dataTables.min.css">
    <script src="https://cdn.datatables.net/buttons/2.1.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.1.1/js/buttons.html5.min.js"></script>

    <!-- Include ExcelJS library for Excel export -->
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/pdfmake.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/vfs_fonts.js"></script>
    </footer>
@endsection
