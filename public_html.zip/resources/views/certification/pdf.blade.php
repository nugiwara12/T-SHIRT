<!-- resources/views/certification/pdf.blade.php -->

<html>
    <title>Baranagay Tabun:PDF Form</title>
<style>

        body {
            font-family: 'Times New Roman', Times, serif; /* Add Times New Roman as the first choice */
            line-height: 1.5; /* Adjust the line height */
            font-size: 16px;
        }

        body::before {
            content: '';
            background: url('admin_assets/img/bgy-ID-img/tabun.png') center center no-repeat;
            background-size: 25rem 25rem; /* Adjust the size as needed */
            opacity: 0.2; /* Adjust the opacity as needed */
            top: 0;
            left: 0;
            bottom: 0;
            right: 0;
            position: absolute;
            z-index: -1;
        }

        .certification {
            max-width: 600px;
            margin: 0 auto;
            display: flex; /* Use flexbox for layout */
            align-items: center; /* Center vertically */
            justify-content: space-between; /* Distribute space between elements */
        }

        .header-left {
            display: flex;
            align-items: center;
        }

        .left-logo,
        .Left Logo {
            height: 8rem;
            position: absolute;
            top: 0;
            left: 2rem;
            z-index: 1; /* Images are stacked on top of the text */
        }


        .right-logo,
        .profile-picture {
            height: 8rem;
            position: absolute;
            top: 0;
            right: 2rem;
            z-index: 1; /* Images are stacked on top of the text */
        }

        .barangay {
            marfin: 0;
            text-align: center;
        }

        .header-title1 {
            font-size: 18px;
            /* font-weight: bold; */
            /* margin: 5px 0; */
        }

        .header-title2 {
            font-size: 24px;
            font-weight: bold;
            /* margin: 5px 0; */
        }

        .header-title3 {
            font-size: 18px;
            font-weight: bold;
        }

        .header {
            text-align: center;
            margin-top: 20px;
        }

        .underline-h2 {
            /* border-bottom: 2px solid #000; */
            /* margin-bottom: 5px; */
        }

        .spaced-element {
            margin: 10px 0;
        }

        .header-tag {
            text-align: left;
            font-size: 16px;
            font-weight: bold;
            margin: 10px 0;
        }

        .clearance {
            margin-top: 20px;
        }

        .name {
            font-weight: bold;
        }

        .purpose {
            font-weight: bold;
        }

        .date {
            font-weight: bold;
        }

        .signature-container,
        .Head-class {
            margin-top: -2rem; /* Use a negative value to move the elements upward */
            margin-left: 12rem;
            /* margin-top: 20px; */

            /* Add size properties */
            width: 240px; /* Replace with your desired width */
            height: 200px; /* Replace with your desired height */
        }

        .opacity-text {
            text-align: center;
            opacity: 0.6;
            margin-top: 20px;
        }
        .address{
            font-weight: bold;
        }
        .baranagay-tabun{
            font-size: 25px;
        }
        .indigency{
            font-weight: bold;
            font-size: 20px;
        }
        .Head-class-sec{
            /* margin-left: 23rem; */
            font-weight: bold;
            font-size: 16px;
        }
        .verify-text-sec{
            font-size: 12px;
            font-weight: bold;
            /* margin-left: 23rem; */
        }
        .Head-class-punong{
            /* margin-left: 26rem; */
            font-weight: bold;
            font-size: 16px;
        }
        .verify-text-punong{
            font-size: 12px;
            font-weight: bold;
            /* margin-left: 22rem; */
        }
        .brgy-position{
            font-weight: none;
            font-size: 15px;
            margin-left: 1px;
        }
        .mark-sign{
            margin-left: 2rem;
        }


        .signature-container {
            position: relative;
            display: inline-block;
        }

        .signature-img {
            width: 150px; /* Set the width of the image as needed */
            height: auto; /* Maintain the aspect ratio */
            position: absolute;
            bottom: 0;
            z-index: 0; /* Set a lower z-index for the image */
        }
    </style>
<body>
<div class="certification">
        <img class="left-logo" src="admin_assets/img/bgy-ID-img/balacat.png" alt="Left Logo">
        <img class="profile-picture" src="admin_assets/img/bgy-ID-img/tabun.png" alt="Profile Picture">
        <div class="barangay">
            <p class="header-title1">Republic of the Philippines <br>Province of Pampanga 
            <br>Mabalacat City <br>OFFICE OF THE  SANGGUNIANG BARANGAY <br> <span class="baranagay-tabun">Barangay Tabun</span></p>
            
            <hr> <span class="indigency">CERTIFICATE OF INDIGENCY</span> <br>
                
            ___________________________________________________________________</hr>

                
        </div>

        <div class="header">
            <h3 class="header-tag">To Whom It May Concern:</h3> 
        </div>

    <div class="clearance">
            <p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; This is to certify that <span class="name">{{ $certification->your_name }}</span>, of legal age, male/female, single/married/widow/widower, filipino citizen, with residence of <span class="address">{{ $certification->address }}</span>, 
            Barangay Tabun, Mabalacat City Pampanga, specimen signature appears below, is an <strong>INDIGENT</strong> and that he/she has visibly no money, property or means of livelihood sufficient and abailable for daily food, shelter and basic necessities for himself and his family.</p>
            <p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; This certification is being issued upon of the request of the above-named person for the puspose of <span class="purpose">{{ $certification->purpose }}</span> issued this <span class="date">{{ \Carbon\Carbon::parse($certification->date)->format('F d, Y') }}</span> at Barangay Tabun, Mabalacat City, Pampanga.</p>
            <p>__________________ <br><span class="mark-sign">Signature</span></p>
        </div>

        
        <!-- <div class="signature-container">
            <img class="Head-class" src="admin_assets/img/signature/unknown3.png" alt="">
        </div><br> -->
        <div>


        </div>
            <p class="verify-text-sec">Checked and Verified by:</p>
        <div>
            <p class="Head-class-sec">JOJO GALANG <br> <span class="brgy-position">Barangay Secretary</span></p>
        </div>
        <div>
            <p class="verify-text-punong">Approved:</p>

            <p class="Head-class-punong">DANILO G. DE LEON <br> <span class="brgy-position">Punong Barangay</span></p><br>
        </div>
        <p class="opacity-text">*(Not Valid without seal)</p>
    </div>

</body>
</html>
