@extends('layout')

@section('content')

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tabun Tabun</title>

    <link rel="stylesheet" href="{{URL::to('admin_assets/css/indegency-create4.css')}}">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11">

</head>

<body>

    <div class="certification">
    <center><h1>Barangay Indigency</h1></center>
    <br>
        <!-- Your existing content -->

        <!-- Form section -->
        <form action="{{ route('certification.store4') }}" method="POST" enctype="multipart/form-data" id="myForm">

        @if(Session::has('success'))
                <div class="custom-box">
                    <div class="alert alert-success" role="alert">
                        {{ Session::get('success') }}
                    </div>
                </div>
            @endif
            @csrf



            <label for="mother_name">Parent Name:</label>
            <input class="form-control" type="text" id="mother_name" name="mother_name" value="{{ old('mother_name') }}" required>
            @error('mother_name')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <label for="your_name">Child Name:</label>
            <input class="form-control" type="text" id="your_name" name="your_name" value="{{ old('your_name') }}" required>
            @error('your_name')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <label for="address">Address:</label>
            <input class="form-control" type="text" id="address" name="address" value="{{ old('address') }}" required>
            @error('address')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <label for="purpose">Purpose to use:</label>
            <input class="form-control" type="text" id="purpose" name="purpose" value="{{ old('purpose') }}" required>
            @error('purpose')
                <span style="color: red;">{{ $message }}</span>
            @enderror


            <label for="age">Age:</label>
            <input class="form-control" type="number" id="age" name="age" value="{{ old('age') }}" required min="1" max="17" pattern="[0-9]+">
            @error('age')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <label for="minor">Select Minor:</label>
            <select class="form-control" name="minor" id="minor" required>
                <option value="minor" @if(old('minor') == 'minor') selected @endif>Minor</option>
            </select>
            @error('minor')
                <span style="color: red;">{{ $message }}</span><br>
            @enderror
            <br>

            <label for="date_of_birth">Date of Birth:</label>
            <input type="date" id="date_of_birth" name="date_of_birth" class="form-control @error('date_of_birth') is-invalid @enderror" value="{{ old('date_of_birth') }}" required/>

            @error('date_of_birth')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
            @enderror

            <label for="date">Date:</label>
            <input class="form-control" type="date" id="date" name="date" value="{{ old('date') }}" required>
            @error('date')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <!-- Your HTML code -->
            <label for="generated_number">Referral Code:</label>
            <input class="form-control" type="text" id="generated_number" name="generated_number" readonly>
            @error('generated_number')
                <span style="color: red;">{{ $message }}</span><br><br>
            @enderror

            <button type="button" onclick="generateNumber()">Generate Number</button><br><br>

            <center><button class="botton-submite" type="button" onclick="confirmSubmit()">Submit</button></center>
        </form>
    </div>


<!-- For Submite Sweet-Alert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function confirmSubmit() {
        Swal.fire({
            title: 'Reminder!',
            text: 'MUST BE ACOMPANED BY PARENT OR GUARDIAN PRIOR TO RELEASE YOUR DOCUMENT.', 
            icon: 'success',
            showCancelButton: true,
            confirmButtonText: 'Yes, submit it!',
            cancelButtonText: 'No, cancel!',
        }).then((result) => {
            if (result.isConfirmed) {
                // If the user clicks "Yes," submit the form
                document.getElementById('myForm').submit();
            }
        });
    }

    // Add a function to generate the number (assuming you have this function)
    function generateNumber() {
        // Your existing generateNumber function logic
    }
</script>



<!-- Generate Code JavaScript code -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
    function generateNumber() {
        // Display SweetAlert confirmation message
        Swal.fire({
            title: 'Reminders',
            text: 'Please screen shot the referal code to get the documents in Barangay Tabun. Thank you',
            icon: 'info',
            showCancelButton: true,
            confirmButtonText: 'Yes, generate it!',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            // Check if the user clicked the "Generate it!" button
            if (result.isConfirmed) {
                const generatedNumberInput = document.getElementById('generated_number');

                // Generate a random number or use your logic to generate one
                const randomNumber = Math.floor(Math.random() * 100000) + 1;

                // Fill the generated number into the input field
                generatedNumberInput.value = randomNumber;

                // Display SweetAlert success message
                Swal.fire({
                    title: 'Barangay Tabun Referral Code !',
                    text: 'Your referral code is: ' + randomNumber,
                    icon: 'success',
                    confirmButtonText: 'OK'
                });
            }
        });
    }
</script>

</body>

</html>
@endsection