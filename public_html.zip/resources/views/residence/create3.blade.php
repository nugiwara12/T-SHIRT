@extends('layouts.app3')
  
@section('title', 'Barangay Residency')
  
@section('contents')

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="styles.css">
    <title>Tabun Tabun</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }

        .residence {
            max-width: 1000px; /* Adjust the maximum width as needed */
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            box-sizing: border-box;
            border-radius: 8px;
            border: solid 5px black;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 5px;
        }

        input {
            margin-bottom: 15px;
            padding: 8px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        /* Media query for responsiveness */
        @media (max-width: 600px) {
            .residence {
                width: 90%;
            }
        }
    </style>
</head>

<body>

        <!-- Form section -->
        <div class="residence">
        <!-- Your existing content -->

        <!-- Form section -->
        <form action="{{ route('residence.store4') }}" method="POST" enctype="multipart/form-data">
        @if(Session::has('success'))
                <div class="custom-box">
                    <div class="alert alert-success" role="alert">
                        {{ Session::get('success') }}
                    </div>
                </div>
            @endif
            @csrf
            <center><h1>Barangay Residence</h1></center>
            <br>
            <label for="mother_name">Parent Name:</label>
            <input class="form-control" type="text" id="mother_name" name="mother_name" value="{{ old('mother_name') }}" required>
            @error('mother_name')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <label for="address">Address:</label>
            <input class="form-control" type="text" id="address" name="address" value="{{ old('address') }}" required>
            @error('address')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <label for="purpose">Purpose to use:</label>
            <input class="form-control" type="text" id="purpose" name="purpose" value="{{ old('purpose') }}" required>
            @error('purpose')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <label for="your_name">Name of Chidlren:</label>
            <input class="form-control" type="text" id="your_name" name="your_name" value="{{ old('your_name') }}" required>
            @error('your_name')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <label for="gender" style="color: black;">Son or Doughter?::</label>
            <select class="form-control @error('gender') is-invalid @enderror" name="gender" id="gender" required ="gender">
                <option value="" disabled {{ old('gender') ? '' : 'selected' }}>Select Type</option>
                <option value="Son" {{ old('gender') == 'Son' ? 'selected' : '' }}>Son</option>
                <option value="Duaghter" {{ old('gender') == 'Duaghter' ? 'selected' : '' }}>Duaghter</option>
            </select>

                <br>


            <label for="date_start">Date of Resident:</label>
            <input class="form-control" type="date" id="date_start" name="date_start" value="{{ old('date_start') }}" required>
            @error('date_start')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <label for="age">Age:</label>
            <input class="form-control" type="number" id="age" name="age" value="{{ old('age') }}" required min="1" max="17" pattern="[0-9]+">
            @error('age')
                <span style="color: red;">{{ $message }}</span>
            @enderror


            <label for="date_of_birth">Date of Birth:</label>
            <input class="form-control" type="date" id="date_of_birth" name="date_of_birth" value="{{ old('date_of_birth') }}" required>
            @error('date_of_birth')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <label for="generated_number">Referal Code:</label>
            <input class="form-control" type="text" id="generated_number" name="generated_number" readonly>
            @error('generated_number')
                <span style="color: red;">{{ $message }}</span><br><br>
            @enderror

            <button type="button" onclick="generateNumber()">Generate Number</button><br><br>

            <input class="submited-botton" type="submit" value="Submit">
        </form>
    </div>


</body>

</html>

<script>
    function generateNumber() {
    const generatedNumberInput = document.getElementById('generated_number');

    // Generate a random number or use your logic to generate one
    const randomNumber = Math.floor(Math.random() * 100000) + 1;

    // Fill the generated number into the input field
    generatedNumberInput.value = randomNumber;
    }
    </script>
@endsection