@extends('layouts.app3')
  
@section('title', 'Barangay Residency')
  
@section('contents')



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="styles.css">
    <title>Barangay Residence</title>
    <style>
    body {
        font-family: 'Arial', sans-serif;
        margin: 0;
        padding: 0;
    }

    .residence {
        width: 9.5in; /* Standard width for letter-sized paper */
        height: 14in; /* Standard height for letter-sized paper */    margin: 50px auto;
        background-color: #fff;
        padding: 20px;
        box-sizing: border-box;
        border-radius: 8px;
        border: solid 5px black;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .barangay h1, .barangay h2, .barangay h3 {
        margin: 5px 0;
    }

    .header h2{
        text-align: center;
        padding-bottom: 20px; /* Adjust the value as needed */
    }

    .clearance {
        margin-top: 20px;
        font-size: 14px;
        line-height: 1.5;
        margin-bottom: 20px; /* Add margin for spacing */
    }

    .clearance p {
        text-align: justify;
        margin-bottom: 10px;
        font-size: 24px;
    }

    .name, .address, .reason {
        font-weight: bold;
    }

    .footer {
        margin-top: 20px;
        text-align: right;
    }

    .footer p {
    text-align: left;
    }

    .footer-design {
        text-align: center;
        margin-top: 20px;
        font-size: 14px;
    }

    .Head-class{
        font-weight: bold;
        margin-left: 30rem;
        font-size: 24px;
    }
    .Head-class-1{
        margin-left: 31.7rem; 
    }
    .header-tag{
        text-align: left;
    }
    .header-title1{
        text-align: center;
        font-size: 1.2rem;
        font-weight: normal;
    }
    .header-title{
        text-align: center;
        font-size: 1rem;
    }
    .header-title2{
        text-align: center;
        font-size: 1.5rem;
    }
    .header-title3{
        text-align: center;
        font-size: 1rem;
        font-weight: normal;
    }


    .opacity-text {
        opacity: 0.7; /* Set the desired opacity value (0.0 to 1.0) */
    }
    .underline-p {
        text-decoration: underline;
    }




    .left-logo,
    .right-logo {
        height: 5rem;
        text-align: left;
    }

    .profile-picture {
        height: 5rem;
    }

    .header-left {
        text-align: left;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    /* Media query for responsive printing */
    @media print {
        #clearance-container {
            width: auto;
            margin: 0;
            box-shadow: none;
        }

        .left-logo,
        .right-logo,
        .profile-picture {
            display: none; /* Hide logos and profile picture when printing */
        }
    }

    .profile-user {
        position: absolute;
        margin-top: 7rem; /* Change 'top' to 'bottom' if needed */
        right: 1;
        height: 8.5rem;
        width: 14.5rem;
        border-radius: 0.1rem;
        z-index: -1; /* Place the image behind the text */
    }



    @media print {
        .no-print {
            display: none;
        }
    }
    .Head-class-sec{
        font-weight: bold;
        text-align: left;
        font-size: 24px;
    }
    .Head-class-1-sec{
        text-align: left;
    }

    .signature-image{
        height: 1rem;
    }
    .back-button {
    display: inline-block;
    padding: 10px 20px;
    margin: 10px 0;
    background-color: #ff0000; /* Red background color */
    color: #fff; /* White text color */
    text-decoration: none; /* Remove underline */
    border-radius: 5px; /* Rounded corners */
    transition: background-color 0.3s; /* Smooth transition for background color */
    }

    .back-button:hover {
        background-color: #cc0000; /* Darker red on hover */
        color: white;
    }

    .gender {
        font-weight: bold;
        /* text-decoration: underline; */
    }

    .date_start {
        font-weight: bold;
        /* text-decoration: underline; */
    }

    </style>
</head>

<body>

    <div class="residence">
        <div class="header-left">
            <img class="left-logo" src="{{URL::to('admin_assets/img/bgy-ID-img/balacat.png')}}" alt="Left Logo">
            <img class="profile-picture" src="{{URL::to('admin_assets/img/bgy-ID-img/tabun.png')}}" alt="Profile Picture">
        </div>
        <div class="barangay">
            <h1 class="header-title1">Republic of the Philippines</h1>
            <h2 class="header-title2">Barangay Tabun</h2>
            <h3 class="header-title3">Mabalacat City</h3>
        </div>

        <div class="header">
            <h2 class="underline-h2">____________________________________________</h2>
            <h2 class="spaced-element">CERTIFICATE OF RESIDENCY</h2>
            <h3 class="header-tag">To Whom It May Concern:</h3>
        </div>

        <div class="clearance">
        <p>This is to certify that <span class="name">{{ $residence->your_name }} </span>, of legal age, male/female, single/married/widow/widower, filipino citizen, with residence of <span class="address">{{ $residence->address }}</span>, 
            Barangay Tabun, Mabalacat City Pampanga, specimen signature appears below, is an <strong>Resident</strong>of this barangay.</p>

            <p>Based on records of this office, he/she has been residing at <span class="address">{{ $residence->address }}</span>, Barangay Tabun, Mabalacat City since <span class="date_start">{{ $residence->date_start }}</span><strong> up to the present.</strong></p>

            <p>This Resident Centification is being issued upon of the request of the above-named for his/her <span class="purpose">{{ $residence->gender }}</span> named <span class="purpose">{{ $residence->purpose }}</span> issued this <span class="date">{{ $residence->created_at->format('l, F j, Y') }}</span> at Barangay Tabun, Mabalacat City, Pampanga.</p>
            <p><strong>Signature</strong>________________</p>
        </div><br><br>

        <div class="footer-design">
            <p class="Head-class">DANILO G. DE LEON</p>
            <p class="Head-class-1">Punong Barangay</p>
        </div>

        <div>
        <img class="signature-image" src="{{URL::to('admin_assets/img/signature/jc.png')}}" alt="">
            <p class="Head-class-sec">JOJO GALANG</p>
            <p class="Head-class-1-sec">Barangay Secretary</p>
        </div>
        <br><br><br>
        <p class="opacity-text">*(Not Valid without seal)</p>
    </div>

</body>
<a class="back-button" href="{{ route('residence.index') }}">Back to List</a>
<a href="{{ route('residence.show.pdf', ['id' => $residence->id]) }}" class="btn btn-primary" target="_blank">Generate PDF</a>

</html>
@endsection