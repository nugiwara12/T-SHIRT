@extends('layouts.app3')
  
@section('title', 'Edit Barangay Residency')
  
@section('contents')

<head>
<style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }

        .residence {
            max-width: 1000px; /* Adjust the maximum width as needed */
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            box-sizing: border-box;
            border-radius: 8px;
            border: solid 5px black;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 5px;
        }

        input {
            margin-bottom: 15px;
            padding: 8px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        /* Media query for responsiveness */
        @media (max-width: 600px) {
            .residence {
                width: 90%;
            }
        }
    </style>
</head>

<form action="{{ route('residence.update', ['id' => $residences->id]) }}" method="POST">
    @csrf
    @method('PUT')

            <label for="mother_name">Parent Name:</label>
            <input class="form-control" type="text" id="mother_name" name="mother_name" value="{{ $residences->mother_name }}" required>

            <label for="address">Address:</label>
            <input class="form-control" type="text" id="address" name="address" value="{{ $residences->address }}" required>

            <label for="purpose">Purpose to use:</label>
            <input class="form-control" type="text" id="purpose" name="purpose" value="{{ $residences->purpose }}" required>

            <label for="your_name">Name of the Son | Daughter::</label>
            <input class="form-control" type="text" id="your_name" name="your_name" value="{{ $residences->your_name }}" required>

            <label for="gender" style="color: black;">Gender:</label>
            <select class="form-control @error('gender') is-invalid @enderror" name="gender" id="gender" required ="gender">
                <option selected disabled>{{ $residences->gender }}</option>
                <option value="Son">Son</option>
                <option value="Duaghter">Duaghter</option>
            </select><br>

            <label for="date_start">Years or Month of Resident?:</label>
            <input class="form-control" type="text" id="date_start" name="date_start" value="{{ $residences->date_start }}" required>

            <label for="date_of_birth">Date of Birth:</label>
            <input class="form-control" type="date" id="date_of_birth" name="date_of_birth" value="{{ $residences->date_of_birth }}" required>

            <label for="age">Age:</label>
            <input class="form-control" type="number" id="age" name="age" value="{{ $residences->age }}"  min="0" pattern="[0-9]+" required>

    <button type="submit">Update</button>
    <br><br><br>
</form>

@endsection
