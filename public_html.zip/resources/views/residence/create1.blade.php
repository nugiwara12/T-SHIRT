@extends('layout')

@section('content')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Baranagay Tabun</title>


    <link rel="shortcut icon" href="{{ URL::to('admin_assets/img/title-logo/tabun.png') }}">
    <link rel="shortcut icon" href="{{ URL::to('admin_assets/img/title-logo/tabun.png') }}" type="image/x-icon">
    <link rel="stylesheet" href="{{URL::to('admin_assets/css/brgy-clearance-create1.css')}}">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11">    
</head>
<body>


    <div class="residence">
        <!-- Your existing content -->

        <!-- Form section -->
        <div class="residence">
        <!-- Your existing content -->

        <!-- Form section -->
        <form action="{{ route('residence.store1') }}" method="POST" enctype="multipart/form-data" id="myForm">

        @if(Session::has('success'))
                <div class="custom-box">
                    <div class="alert alert-success" role="alert">
                        {{ Session::get('success') }}
                    </div>
                </div>
            @endif
            @csrf
            <center><h1>Barangay Residence</h1></center>
            <br>
            <label for="mother_name">Parent Name:</label>
            <input class="form-control" type="text" id="mother_name" name="mother_name" value="{{ old('mother_name') }}" required>
            @error('mother_name')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <label for="address">Address:</label>
            <input class="form-control" type="text" id="address" name="address" value="{{ old('address') }}" required>
            @error('address')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <label for="purpose">Purpose to use:</label>
            <input class="form-control" type="text" id="purpose" name="purpose" value="{{ old('purpose') }}" required>
            @error('purpose')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <label for="your_name">Your Name:</label>
            <input class="form-control" type="text" id="your_name" name="your_name" value="{{ old('your_name') }}" required>
            @error('your_name')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <label for="gender" style="color: black;">Gender:</label>
            <select class="form-control @error('gender') is-invalid @enderror" name="gender" id="gender" required ="gender">
                <option value="" disabled {{ old('gender') ? '' : 'selected' }}>Select Type</option>
                <option value="Son" {{ old('gender') == 'Son' ? 'selected' : '' }}>Son</option>
                <option value="Duaghter" {{ old('gender') == 'Duaghter' ? 'selected' : '' }}>Duaghter</option>
            </select>

                <br>


            <label for="date_start">Date of Resident:</label>
            <input class="form-control" type="date" id="date_start" name="date_start" value="{{ old('date_start') }}" required>
            @error('date_start')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <label for="age">Age:</label>
            <input class="form-control" type="number" id="age" name="age" value="{{ old('age') }}" required min="18" max="200" pattern="[0-9]+">
            @error('age')
                <span style="color: red;">{{ $message }}</span>
            @enderror


            <label for="date_of_birth">Date of Birth:</label>
            <input class="form-control" type="date" id="date_of_birth" name="date_of_birth" value="{{ old('date_of_birth') }}" required>
            @error('date_of_birth')
                <span style="color: red;">{{ $message }}</span>
            @enderror

            <label for="generated_number">Referal Code:</label>
            <input class="form-control" type="text" id="generated_number" name="generated_number" readonly>
            @error('generated_number')
                <span style="color: red;">{{ $message }}</span><br><br>
            @enderror

            <button type="button" onclick="generateNumber()">Generate Number</button><br><br>

            <button class="botton-submite" type="button" onclick="confirmSubmit()">Submit</button>
    </form>
</div>



<!-- For Submite Sweet-Alert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function confirmSubmit() {
        Swal.fire({
            title: 'Reminder!',
            text: 'CLICK YES TO SUBMIT IT AND THE FORM WILL BE SUBMITTED!.', 
            icon: 'success',
            showCancelButton: true,
            confirmButtonText: 'Yes, submit it!',
            cancelButtonText: 'No, cancel!',
        }).then((result) => {
            if (result.isConfirmed) {
                // If the user clicks "Yes," submit the form
                document.getElementById('myForm').submit();
            }
        });
    }

    // Add a function to generate the number (assuming you have this function)
    function generateNumber() {
        // Your existing generateNumber function logic
    }
</script>



<!-- Generate Code JavaScript code -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
    function generateNumber() {
        // Display SweetAlert confirmation message
        Swal.fire({
            title: 'Reminders',
            text: 'Please screen shot the referal code to get the documents in Barangay Tabun. Thank you',
            icon: 'info',
            showCancelButton: true,
            confirmButtonText: 'Yes, generate it!',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            // Check if the user clicked the "Generate it!" button
            if (result.isConfirmed) {
                const generatedNumberInput = document.getElementById('generated_number');

                // Generate a random number or use your logic to generate one
                const randomNumber = Math.floor(Math.random() * 100000) + 1;

                // Fill the generated number into the input field
                generatedNumberInput.value = randomNumber;

                // Display SweetAlert success message
                Swal.fire({
                    title: 'Barangay Tabun Referral Code !',
                    text: 'Your referral code is: ' + randomNumber,
                    icon: 'success',
                    confirmButtonText: 'OK'
                });
            }
        });
    }
</script>


</body>
</html>



@endsection