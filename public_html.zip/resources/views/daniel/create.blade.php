@extends('layouts.app3')
  
@section('title', 'CREATE DANIEL AGUSTIN POST ')
  
@section('contents')

    <form action="{{ route('daniel.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="row mb-3">
            <div class="col">
                <label for="title">Title</label>
                <input type="text" name="title" class="form-control form-control-user @error('title')is-invalid @enderror" placeholder="Enter Title">
                <div class="invalid-feedback">
                    Please provide Title.
                </div>
            </div>
            <div class="col">
            <label for="image">Image</label>
            <input type="file" name="image" accept="image/*" class="form-control form-control-user @error('image') is-invalid @enderror"><br>
            <div class="invalid-feedback">
                Please provide a valid image.
            </div>
        </div>

        <div class="row mb-3">
        <div class="col">
            <label for="description">Description</label>
            <textarea name="description" class="form-control form-control-user @error('description') is-invalid @enderror" rows="3"></textarea>
            <div class="invalid-feedback">
                Please provide a valid description.
            </div>
        </div>
    </div>

            
 
    <div class="row">
            <div class="col">
                <button type="submit" class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="Submit">Submit</button>
                <a href="{{ route('daniel.index') }}" class="btn btn-secondary">Back</a>

            </div>
        </div>

    </form>


    


@endsection