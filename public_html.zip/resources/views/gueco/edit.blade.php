@extends('layouts.app3')
  
@section('title', 'EDIT GLENN GUECO POST')
  
@section('contents')

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css">

    <hr />
    <form action="{{ route('gueco.update', $guecos->id) }}" method="POST">
        @csrf
        @method('PUT')

        <div class="row mb-3">
        <div class="col">
            <label for="title">Title</label>
            <input type="text" name="title" class="form-control form-control-user @error('title')is-invalid @enderror" placeholder="Enter Title" value="{{ old('title', $christoper->title) }}">
            <div class="invalid-feedback">
                {{ $errors->first('title') }}
            </div>
        </div>
        
        <div class="col">
        <label for="image">Image</label>
        <input type="file" name="image" accept="image/*" class="form-control form-control-user @error('image') is-invalid @enderror">
        
        @if ($gueco->image)
            <div class="mt-2">
                <label for="oldImage">Old Image</label>
                <br>
                <img src="{{ asset($gueco->image) }}" alt="Old Image" style="max-width: 100%; height: auto;">
            </div>
        @endif

        <div class="invalid-feedback">
            {{ $errors->first('image') }}
        </div>
    </div>





        <div class="row mb-3">
        <div class="col">
            <label for="description">Description</label>
            <textarea name="description" id="description" class="form-control form-control-user @error('description') is-invalid @enderror">{{ old('description', $christoper->description) }}</textarea>
            <div class="invalid-feedback">
                {{ $errors->first('description') }}
            </div>
        </div>
    </div>

    <div class="row">
        <div class="d-grid gap-2">
            <button type="submit" class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="Submit">Submit</button>
        </div>
    </div>

    <div class="row mt-2">
        <div class="d-grid gap-2">
            <!-- You can add a back button or any other actions here -->
            <a href="{{ route('gueco.index') }}" class="btn btn-secondary">Back</a>
        </div>
    </div>


    </form>


<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
<script>
    $(document).ready(function () {
        $('#description').summernote({
            toolbar: [],
            readOnly: true
        });
    });
</script>
@endsection