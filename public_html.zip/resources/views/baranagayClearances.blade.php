@extends('layout')

@section('content')


<link rel="stylesheet" href="{{URL::to('admin_assets/css/brgy-clearance-create.css')}}">

@if(Session::has('success'))
        <div class="alert alert-success" role="alert">
            {{ Session::get('success') }}
        </div>
    @endif
    
    <form action="{{ route('barangay_clearances.store') }}" method="POST">
        @csrf
        <label for="name">Name:</label>
        <input type="text" name="name" required>
        <br>
        <label for="address">Address:</label>
        <input type="text" name="address" required>
        <br>
        <label for="reason">Purpose to use:</label>
        <textarea name="reason" required></textarea>
        <br>
        <input type="hidden" name="type" value="minor">

        <button type="submit">Submit</button>
    </form>

</body>
</html>

@endsection
