@extends('layouts.app4')
  
@section('title', 'View Baranagay ID')
  
@section('contents')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="{{ URL::to('admin_assets/css/ID-frontshow.css') }}">
</head>
<body>
    

@if(Session::has('success'))
        <div class="alert alert-success" role="alert">
            {{ Session::get('success') }}
        </div>
    @endif
    
<center>
    <div id="clearance-container">
    <div class="watermark-bg"></div>
    <div class="certification">
        <div class="header-left">
            <img class="left-logo" src="{{URL::to('admin_assets/img/bgy-ID-img/tabun.png')}}" alt="Left Logo">
            <img class="right-logo" src="{{URL::to('admin_assets/img/bgy-ID-img/balacat.png')}}" alt="Profile Picture">
        </div>
        <p class="header-name-tag" style="font-size:10px;">Republic of the Philippines <br> Province of Pampanga <br> Mabalacat City <br> <strong>Barangay Tabun</strong></p>
            
        <p class="behind-text"><strong>BARANGAY ID</strong></p>
 
        <img class="profile-user" src="{{ asset($barangay_ids->image) }}" alt="profile user">

        <section class="info-elements">
            <p class="body-p"><strong>ID No:</strong> <span class="dynamic-content">{{ $barangay_ids->id }}</span>
            <span style="padding-right: 11.9rem;"></span> <strong>Name:</strong> <span class="dynamic-content">{{ $barangay_ids->name }}</span></p>  
            

            <p class="body-p"><strong>Address:</strong> <span class="dynamic-content">{{ $barangay_ids->address }}</span> 
            <span style="padding-right: 1.9rem;"></span> <strong>Date of Birth:</strong> <span class="dynamic-content">{{ $barangay_ids->date_of_birth }}</span></p>
            
            <p class="body-p"><strong>Place of Birth:</strong> <span class="dynamic-content">{{ $barangay_ids->place_of_birth }}</span>
            <span style="padding-right: 10rem;"></span> <strong>Citizenship:</strong> <span class="dynamic-content">{{ $barangay_ids->citizenship }}</span></p>
            
            <p class="body-p"><strong>Gender:</strong> <span class="dynamic-content">{{ $barangay_ids->gender }}</span>
            <span style="padding-right: 11rem;"></span> <strong>Civil Status:</strong> <span class="dynamic-content">{{ $barangay_ids->civil_status }}</span></p>
            
            <p class="body-p"><strong>Contact No:</strong> <span class="dynamic-content">{{ $barangay_ids->contact_no }}</span></p>
            <p class="body-p"><strong>Signature</strong>__________</p>
        </section>
    </div><br>

    </center>
    <a class="back-button" href="{{ route('barangay-clearance-id.index') }}">Back to List</a>
    <a href="{{ route('barangay-clearance-id.show.pdf', ['id' => $barangay_ids->id]) }}" class="btn btn-primary" target="_blank">Generate PDF</a>

</body>
</html>
@endsection