@extends('layouts.app4')
  
@section('title', 'View Baranagay ID')
  
@section('contents')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="{{ URL::to('admin_assets/css/ID-backshow.css') }}">

</head>
<body>

@if(Session::has('success'))
        <div class="alert alert-success" role="alert">
            {{ Session::get('success') }}
        </div>
    @endif

<center>
<div class="info">
<div class="watermark-bg"></div>
    <center><p>Emergency Contact Information</p></center>
    <div class="person">
        <p class="body-p"><strong>Name:</strong> <span class="dynamic-content">{{ $barangay_ids->guardian }}</span>
        <span style="padding-right: 7rem;"></span> <strong>Address:</strong> <span class="dynamic-content">{{ $barangay_ids->address }}</span></p>
        
        <p class="body-p"><strong>Contact No:</strong> <span class="dynamic-content">{{ $barangay_ids->contact_no }}</span>
        <span style="padding-right: 5rem;"></span> <strong>Relation:</strong> <span class="dynamic-content">{{ $barangay_ids->relation }}</span></p>
    </div>
    <div>
        <p class="date-expirations">Date Issues :  <span style="padding-right: 4rem;"></span>  <span>Expiration :</span>  </p>
    </div>

    <div class="box-container">
        <img class="profile-user1" src="{{URL::to('admin_assets/img/bgy-ID-img/boz.png')}}" alt="profile user">
        <img class="profile-user1" src="{{URL::to('admin_assets/img/bgy-ID-img/boz.png')}}" alt="profile user">
    </div>

    <img class="profile-user" src="{{URL::to('admin_assets/img/bgy-ID-img/kapDan2.png')}}" alt="profile user">

    <div class="person" style="text-align: right;">
        <p class="hon-punong-p"><strong>HON. DANILO G. DE LEON <br></strong>Punong Barangay</p>
        <!-- <p class="hon-punong-p">Punong Barangay</p> -->
    </div>
</div><br>
</center>
<a class="back-button" href="{{ route('barangay-clearance-id.index') }}">Back to List</a>
<a href="{{ route('generatePdf2', ['id' => $barangay_ids->id]) }}" class="btn btn-primary" target="_blank">Generate PDF</a>
</body>
</html>
@endsection