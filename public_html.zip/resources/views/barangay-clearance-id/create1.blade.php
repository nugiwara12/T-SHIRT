@extends('layout')
  
  
@section('contents')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="{{ URL::to('admin_assets/css/ID-edit.css') }}">
</head>
<body>

    <form method="POST" action="{{ route('barangay-clearance-id.store1') }}" enctype="multipart/form-data">
        
        if(Session::has('success'))
            <div class="custom-box">
                <div class="alert alert-success" role="alert">
                    {{ Session::get('success') }}
                </div>
            </div>
        @endif
        @csrf

        <div id="clearance-container">
        <h1>Barangay ID</h1>
        <section class="info-elements">
        <!-- <label for="id_no">ID No:</label>
        <input type="text" id="id_no" name="id_no" value="" required readonly/> -->

        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="" required/>

        <label for="address">Address:</label>
        <input type="text" id="address" name="address" value="" required/>

        <label for="date_of_birth">Date of Birth:</label>
        <input type="date" id="date_of_birth" name="date_of_birth" required/>

        <label for="place_of_birth">Place of Birth:</label>
        <input type="text" id="place_of_birth" name="place_of_birth" value="" required/>

        <label for="age">Age:</label>
        <input class="form-control" type="number" id="age" name="age" value="{{ old('age') }}" required min="18" pattern="[0-9]+">
        @error('age')
            <span style="color: red;">{{ $message }}</span>
        @enderror


        <label for="citizenship">Citizenship:</label>
        <input type="text" id="citizenship" name="citizenship" value="" required/>

    </section>

    <section class="info-elements">
        <label for="gender" class="form-label" style="color: black;">Gender:</label>
        <select class="form-control @error('gender') is-invalid @enderror" name="gender" id="gender" required ="gender">
            <option value="" disabled {{ old('gender') ? '' : 'selected' }}>Select Gender</option>
            <option value="Male" {{ old('gender') == 'Male' ? 'selected' : '' }}>Male</option>
            <option value="Female" {{ old('gender') == 'Female' ? 'selected' : '' }}>Female</option>
        </select>

        <label for="civil_status">Civil Status:</label>
        <input type="text" id="civil_status" name="civil_status" value="" required/>

        <label for="contact_no">Contact No.:</label>
        <input type="text" id="contact_no" name="contact_no" value="" required/>

        <label for="relation">Relation:</label>
        <input type="text" id="relation" name="relation" value="" required/>

        <label for="guardian">Guardian:</label>
        <input type="text" id="guardian" name="guardian" value="" required/>

        <label for="image">Image:</label>
        <input type="file" id="image" class="form-control-file" name="image" accept="image/*" required/>

        <center><button type="submit">Submit</button></center>
    </section>
</form>
</body>
</html>



