@extends('layouts.app3')
  
@section('title', 'Edit Barangay ID')
  
@section('contents')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="{{ URL::to('admin_assets/css/brgy-ID-create.css') }}">

</head>
<body>

@if(Session::has('success'))
        <div class="alert alert-success" role="alert">
            {{ Session::get('success') }}
        </div>
    @endif

<form action="{{ route('barangay-clearance-id.update', ['id' => $id]) }}" method="POST" enctype="multipart/form-data">
    @csrf

    <div class="mb-3">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="{{ $barangay_ids->name }}" required/>
    </div>

    <div class="mb-3">
        <label for="address">Address:</label>
        <input type="text" id="address" name="address" value="{{ $barangay_ids->address }}" required/>
    </div>
    <div class="mb-3">
        <label for="date_of_birth">Date of Birth:</label>
        <input type="date" id="date_of_birth" name="date_of_birth" value="{{ $barangay_ids->date_of_birth }}" required/>
    </div>

    <div class="mb-3">
        <label for="place_of_birth">Place of Birth:</label>
        <input type="text" id="place_of_birth" name="place_of_birth" value="{{ $barangay_ids->place_of_birth }}" required/>
    </div>

    <div class="mb-3">
        <label for="age">Age:</label>
        <input type="number" id="age" name="age" value="{{ $barangay_ids->age }}" required min="18" pattern="[0-9]+" required>
    </div>

    <div class="mb-3">
        <label for="citizenship">Citizenship:</label>
        <input type="text" id="citizenship" name="citizenship" value="{{ $barangay_ids->citizenship }}" required/>
    </div>

    </section>

    <div class="mb-3">
        <label for="gender" class="form-label" style="color: black;">Gender:</label>
        <select class="form-control @error('gender') is-invalid @enderror" name="gender" id="gender" required ="gender" value="{{ $barangay_ids->gender }}" required>
            <option selected disabled>{{ $barangay_ids->gender }}</option>
            <option value="Male" {{ old('gender') == 'Male' ? 'selected' : '' }}>Male</option>
            <option value="Female" {{ old('gender') == 'Female' ? 'selected' : '' }}>Female</option>
        </select>
    </div>

        <!-- <label for="gender">Gender:</label>
        <input type="text" id="gender" name="gender" value="{{ $barangay_ids->gender }}" required/> -->
    <div class="mb-3">
        <label for="civil_status">Civil Status:</label>
        <input type="text" id="civil_status" name="civil_status" value="{{ $barangay_ids->civil_status }}" required/>
    </div>

    <div class="mb-3">
        <label for="contact_no">Contact No.:</label>
        <input type="text" id="contact_no" name="contact_no" value="{{ $barangay_ids->contact_no }}" required/>
    </div>

    <div class="mb-3">
        <label for="relation">Relation:</label>
        <input type="text" id="relation" name="relation" value="{{ $barangay_ids->relation }}" required/>
    </div>

    <div class="mb-3">
        <label for="guardian">Guardian:</label>
        <input type="text" id="guardian" name="guardian" value="{{ $barangay_ids->guardian }}" required/>
    </div>

        <center><button type="submit">Submit</button></center>
    </section>
</div>
</form>


</body>
</html>

@endsection