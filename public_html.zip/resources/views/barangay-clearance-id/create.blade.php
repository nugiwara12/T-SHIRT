@extends('layouts.app3')
  
@section('title', 'Create Baranagay ID')
  
@section('contents')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!-- <link rel="stylesheet" href="{{ URL::to('admin_assets/css/ID-edit.css') }}"> -->
    <link rel="stylesheet" href="{{ URL::to('admin_assets/css/brgy-ID-create.css') }}">


</head>
<body>
@if(Session::has('success'))
        <div class="alert alert-success" role="alert">
            {{ Session::get('success') }}
        </div>
    @endif

    <form method="POST" action="{{ route('barangay-clearance-id.store') }}" enctype="multipart/form-data">
        @csrf

            <div class="mb-3">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" class="form-control @error('name') is-invalid @enderror" value="{{ old('name') }}" required/>

            @error('name')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="address">Address:</label>
            <input type="text" id="address" name="address" class="form-control @error('address') is-invalid @enderror" value="{{ old('address') }}" required/>

            @error('address')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="date_of_birth">Date of Birth:</label>
            <input type="date" id="date_of_birth" name="date_of_birth" class="form-control @error('date_of_birth') is-invalid @enderror" value="{{ old('date_of_birth') }}" required/>

            @error('date_of_birth')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="place_of_birth">Place of Birth:</label>
            <input type="text" id="place_of_birth" name="place_of_birth" class="form-control @error('place_of_birth') is-invalid @enderror" value="{{ old('place_of_birth') }}" required/>

            @error('place_of_birth')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="age">Age:</label>
            <input class="form-control" type="number" id="age" name="age" value="{{ old('age') }}" required min="18" pattern="[0-9]+">
            @error('age')
                <span style="color: red;">{{ $message }}</span>
            @enderror
        </div>

        <div class="mb-3">
            <label for="citizenship" class="form-label">Citizenship:</label>
            <input type="text" id="citizenship" name="citizenship" class="form-control @error('citizenship') is-invalid @enderror" value="{{ old('citizenship') }}" required/>

            @error('citizenship')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
            @enderror
        </div>


        <div class="mb-3">
            <label for="gender" class="form-label" style="color: black;">Gender:</label>
            <select class="form-control @error('gender') is-invalid @enderror" name="gender" id="gender" required ="gender">
                <option value="" disabled {{ old('gender') ? '' : 'selected' }}>Select Gender</option>
                <option value="Male" {{ old('gender') == 'Male' ? 'selected' : '' }}>Male</option>
                <option value="Female" {{ old('gender') == 'Female' ? 'selected' : '' }}>Female</option>
            </select>

            @error('gender')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="civil_status">Civil Status:</label>
            <input type="text" id="civil_status" name="civil_status" class="form-control @error('civil_status') is-invalid @enderror" value="{{ old('civil_status') }}" required/>

            @error('civil_status')
            <div style="color: red;">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="contact_no">Contact No.:</label>
            <input type="text" id="contact_no" name="contact_no" class="form-control @error('contact_no') is-invalid @enderror" value="{{ old('contact_no') }}" required/>

            @error('contact_no')
            <div style="color: red;">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="relation">Relation:</label>
            <input type="text" id="relation" name="relation" class="form-control @error('relation') is-invalid @enderror" value="{{ old('relation') }}" required/>

            @error('relation')
            <div style="color: red;">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="guardian">Guardian:</label>
            <input type="text" id="guardian" name="guardian" class="form-control @error('guardian') is-invalid @enderror" value="{{ old('guardian') }}" required/>

            @error('guardian')
            <div style="color: red;">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="image">Image:</label>
            <input type="file" id="image" class="form-control-file @error('image') is-invalid @enderror" name="image" accept="image/*" value="{{ old('image') }}" required/>

            @error('image')
            <div style="color: red;">{{ $message }}</div>
            @enderror
        </div>

        <label for="generated_number">Referal Code:</label>
            <input class="form-control" type="text" id="generated_number" name="generated_number" readonly>
            @error('generated_number')
                <span style="color: red;">{{ $message }}</span><br><br>
            @enderror

        <br><button type="button" onclick="generateNumber()">Generate Number</button><br><br>

        <center><button type="submit">Submit</button></center>
</form>

<script>
    function generateNumber() {
    const generatedNumberInput = document.getElementById('generated_number');

    // Generate a random number or use your logic to generate one
    const randomNumber = Math.floor(Math.random() * 100000) + 1;

    // Fill the generated number into the input field
    generatedNumberInput.value = randomNumber;
}
</script>

</body>
</html>


@endsection
