@extends('layout')
  
  
@section('contents')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="{{ URL::to('admin_assets/css/minor-creat6.css') }}">
    <link rel="shortcut icon" href="{{ URL::to('admin_assets/img/title-logo/tabun.png') }}">
    <link rel="shortcut icon" href="{{ URL::to('admin_assets/img/title-logo/tabun.png') }}" type="image/x-icon">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11">
</head>
<body>


    <form method="POST" action="{{ route('barangay-clearance-id.store7') }}" enctype="multipart/form-data" id="myForm">

        @if(Session::has('success'))
            <div class="alert alert-success" role="alert">
                {{ Session::get('success') }}
            </div>
        @endif
        @csrf

            <div class="mb-3">
                <h1>Barangay ID</h1>
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" class="form-control @error('name') is-invalid @enderror" value="{{ old('name') }}" required/>

            @error('name')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="address">Address:</label>
            <input type="text" id="address" name="address" class="form-control @error('address') is-invalid @enderror" value="{{ old('address') }}" required/>

            @error('address')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="date_of_birth">Date of Birth:</label>
            <input type="date" id="date_of_birth" name="date_of_birth" class="form-control @error('date_of_birth') is-invalid @enderror" value="{{ old('date_of_birth') }}" required/>

            @error('date_of_birth')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="place_of_birth">Place of Birth:</label>
            <input type="text" id="place_of_birth" name="place_of_birth" class="form-control @error('place_of_birth') is-invalid @enderror" value="{{ old('place_of_birth') }}" required/>

            @error('place_of_birth')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
            @enderror
        </div>

        <div class="mb-3">
        <label for="age">Age:</label>
        <input class="form-control" type="number" id="age" name="age" value="{{ old('age') }}" required min="1" max="17" pattern="[0-9]+">
        @error('age')
            <span style="color: red;">{{ $message }}</span>
        @enderror
        </div>



        <div class="mb-3">
            <label for="citizenship" class="form-label">Citizenship:</label>
            <input type="text" id="citizenship" name="citizenship" class="form-control @error('citizenship') is-invalid @enderror" value="{{ old('citizenship') }}" required/>

            @error('citizenship')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
            @enderror
        </div>


        <div class="mb-3">
            <label for="gender" class="form-label" style="color: black;">Gender:</label>
            <select class="form-control @error('gender') is-invalid @enderror" name="gender" id="gender" required ="gender">
                <option value="" disabled {{ old('gender') ? '' : 'selected' }}>Select Gender</option>
                <option value="Male" {{ old('gender') == 'Male' ? 'selected' : '' }}>Male</option>
                <option value="Female" {{ old('gender') == 'Female' ? 'selected' : '' }}>Female</option>
            </select>

            @error('gender')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="civil_status">Civil Status:</label>
            <input type="text" id="civil_status" name="civil_status" class="form-control @error('civil_status') is-invalid @enderror" value="{{ old('civil_status') }}" required/>

            @error('civil_status')
            <div style="color: red;">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="contact_no">Contact No.:</label>
            <input type="text" id="contact_no" name="contact_no" class="form-control @error('contact_no') is-invalid @enderror" value="{{ old('contact_no') }}" required/>

            @error('contact_no')
            <div style="color: red;">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="relation">Relation:</label>
            <input type="text" id="relation" name="relation" class="form-control @error('relation') is-invalid @enderror" value="{{ old('relation') }}" required/>

            @error('relation')
            <div style="color: red;">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="guardian">Guardian:</label>
            <input type="text" id="guardian" name="guardian" class="form-control @error('guardian') is-invalid @enderror" value="{{ old('guardian') }}" required/>

            @error('guardian')
            <div style="color: red;">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-3">
            <label for="image">Image:</label>
            <input type="file" id="image" class="form-control-file @error('image') is-invalid @enderror" name="image" accept="image/*" value="{{ old('image') }}" required/>

            @error('image')
            <div style="color: red;">{{ $message }}</div>
            @enderror
        </div>
        

        <label for="generated_number">Referal Code::</label>
            <input class="form-control" type="text" id="generated_number" name="generated_number" readonly>
            @error('generated_number')
                <span style="color: red;">{{ $message }}</span><br><br>
            @enderror

        <br><button type="button" onclick="generateNumber()">Generate Number</button><br><br>

        <center><button class="botton-submite" type="button" onclick="confirmSubmit()">Submit</button></center>
</form>



<!-- For Submite Sweet-Alert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function confirmSubmit() {
        Swal.fire({
            title: 'Reminder!',
            text: 'MUST BE ACOMPANED BY PARENT OR GUARDIAN PRIOR TO RELEASE YOUR DOCUMENT.', 
            icon: 'success',
            showCancelButton: true,
            confirmButtonText: 'Yes, submit it!',
            cancelButtonText: 'No, cancel!',
        }).then((result) => {
            if (result.isConfirmed) {
                // If the user clicks "Yes," submit the form
                document.getElementById('myForm').submit();
            }
        });
    }

    // Add a function to generate the number (assuming you have this function)
    function generateNumber() {
        // Your existing generateNumber function logic
    }
</script>



<!-- Generate Code JavaScript code -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
    function generateNumber() {
        // Display SweetAlert confirmation message
        Swal.fire({
            title: 'Reminders',
            text: 'Please screen shot the referal code to get the documents in Barangay Tabun. Thank you',
            icon: 'info',
            showCancelButton: true,
            confirmButtonText: 'Yes, generate it!',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            // Check if the user clicked the "Generate it!" button
            if (result.isConfirmed) {
                const generatedNumberInput = document.getElementById('generated_number');

                // Generate a random number or use your logic to generate one
                const randomNumber = Math.floor(Math.random() * 100000) + 1;

                // Fill the generated number into the input field
                generatedNumberInput.value = randomNumber;

                // Display SweetAlert success message
                Swal.fire({
                    title: 'Barangay Tabun Referral Code !',
                    text: 'Your referral code is: ' + randomNumber,
                    icon: 'success',
                    confirmButtonText: 'OK'
                });
            }
        });
    }
</script>
</body>
</html>
