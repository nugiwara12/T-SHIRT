<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Tabun: PDF FORM</title>


    <style>

.info {
    /* display: flex; */
    flex-direction: column;
    justify-content: center;
    align-items: left;
    text-align: center;
    padding: 20px;
    border: solid black 1px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(241, 241, 241, 0.1);
    max-width: 690px;
    background-color: rgba(255, 255, 255, 0.7);
    position: relative;
    height: 177px; /* Adjust the height as needed */
    width: 290px;
    word-wrap: break-word; /* Ensure long words are broken and don't overflow the container */
}

.person {
    margin-top: 1rem;
}

h1, h2 {
    color: black;
}

p {
    margin: 5px 0;
    font-family: 'Times New Roman', Times, serif; /* Add Times New Roman as the first choice */

}

.date-expirations {
    text-align: center;
    font-size: 10px;
    background-color: rgb(242, 63, 63);
    color: whitesmoke;
}
.hon-punong-p{
    font-size: 10px;
}
.body-p{
    text-align: left;
    font-size: 7px;
}

.box-container {
    display: flex;
    justify-content: space-between;
    width: 150px; /* Adjust the maximum width as needed */
    margin: 0 auto; /* Center the container horizontally */
}

.profile-user1 {
    width: 2rem; /* Adjust the width of each box */
    border: 1px solid #000; /* Add a border for visual separation */
    margin: 10px; /* Add some margin between the boxes */
}

.profile-user {
    position: absolute;
    margin-top: -2.5rem; /* Change 'top' to 'bottom' */
    right: 1rem;
    height: 32%;
    width: 25%;
    border-radius: 0.1rem;
    z-index: 1; /* Adjust the z-index value, make sure it's lower than the text's z-index */
}
.watermark-bg {
        content: '';
        background: url('admin_assets/img/wallpaper/baragayTabun.png') center center no-repeat;
        background-size: 19rem 12rem; /* Adjust the size as needed */
        opacity: 0.2; /* Adjust the opacity as needed */
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        position: absolute;
        z-index: -1;
    }
    .signature-container,
    .Head-class {
        margin-top: -1.8rem; /* Use a negative value to move the elements upward */
        margin-left: 6.5rem;
        /* margin-top: 20px; */

        /* Add size properties */
        width: 165px; /* Replace with your desired width */
        height: 130px; /* Replace with your desired height */
    }

    </style>
</head>
<body>
<center>
<div class="info">
<div class="watermark-bg"></div>
    <center><p>Emergency Contact Information</p></center>
    <div class="person">
        <p class="body-p"><strong>Name:</strong> <span class="dynamic-content">{{ $barangay_ids->guardian }}</span>
        <span style="padding-right: 7rem;"></span> <strong>Address:</strong> <span class="dynamic-content">{{ $barangay_ids->address }}</span></p>
        
        <p class="body-p"><strong>Contact No:</strong> <span class="dynamic-content">{{ $barangay_ids->contact_no }}</span>
        <span style="padding-right: 5rem;"></span> <strong>Relation:</strong> <span class="dynamic-content">{{ $barangay_ids->relation }}</span></p>
    </div>
    <div>
        <p class="date-expirations">Date Issues : {{ $barangay_ids->created_at->format('F j, Y') }} <span>Expiration :</span>  </p>
    </div>

    <div class="box-container">
        <img class="profile-user1" src="admin_assets/img/bgy-ID-img/boz.png" alt="profile user">
        <img class="profile-user1" src="admin_assets/img/bgy-ID-img/boz.png" alt="profile user">
    </div>

    <div class="signature-container">
            <img class="Head-class" src="admin_assets/img/signature/unknown4.png" alt="">
    </div>
</div><br>

       
    </center>
</body>
</html>