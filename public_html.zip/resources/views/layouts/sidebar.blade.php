<link rel="stylesheet" href="{{ asset('admin_assets/css/sidebar-icon.css') }}">
<link rel="stylesheet" href="{{ asset('admin_assets/css/sidebar-logo.css') }}">


<!---------------------------------------------------------(Admin) ---------------------------------------------------------------------------->



@if (auth()->check() && auth()->user()->role == 'Admin')

<ul class="navbar-nav sidebar" style="background: #8b0000" id="accordionSidebar">
    
  <!-- Sidebar - Brand -->
  <center><a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{route('dashboard')}}">
    <div class="sidebar-brand-icon">
    <img class="sidebar-logo" src="{{URL::to('admin_assets/img/bgy-ID-img/tabun.png')}}" alt="Left Logo">
    </div>
    <div class="sidebar-brand-text mx-3"><sup></sup></div>
  </a><br></center>
  
  <!-- Divider -->
  <hr class="sidebar-divider my-0">
  
  <!-- Nav Item - Dashboard -->
  <li class="nav-item">
    <a class="nav-link" href="{{ route('dashboard') }}">
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="bi bi-window" viewBox="0 0 16 16">
    <path d="M2.5 4a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1m2-.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0m1 .5a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1"/>
    <path d="M2 1a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V3a2 2 0 0 0-2-2zm13 2v2H1V3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1M2 14a1 1 0 0 1-1-1V6h14v7a1 1 0 0 1-1 1z"/>
    </svg>
      <span class="sidebar-icon" style="color:#FFFFFF" data-toggle="tooltip" data-placement="top" title="Dashboard">Dashboard</span></a>
  </li>
                
            <li class="nav-item">
                        <a class="nav-link" href="/index">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="bi bi-envelope-check" viewBox="0 0 16 16">
                            <path d="M2 2a2 2 0 0 0-2 2v8.01A2 2 0 0 0 2 14h5.5a.5.5 0 0 0 0-1H2a1 1 0 0 1-.966-.741l5.64-3.471L8 9.583l7-4.2V8.5a.5.5 0 0 0 1 0V4a2 2 0 0 0-2-2zm3.708 6.208L1 11.105V5.383zM1 4.217V4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v.217l-7 4.2z"/>
                            <path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0m-1.993-1.679a.5.5 0 0 0-.686.172l-1.17 1.95-.547-.547a.5.5 0 0 0-.708.708l.774.773a.75.75 0 0 0 1.174-.144l1.335-2.226a.5.5 0 0 0-.172-.686"/>
                            </svg>
                            <span class="sidebar-icon" style="color:#FFFFFF" data-toggle="tooltip" data-placement="top" title="List of Message">List of Message</span></a>
                        </li>

            <li class="nav-item">
              <a class="nav-link" href="/usermanagement">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="bi bi-person-circle" viewBox="0 0 16 16">
                    <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
                    <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"/>
                    </svg>
                <span class="sidebar-icon" style="color:#FFFFFF" data-toggle="tooltip" data-placement="top" title="Add User">Add User</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="bi bi-person" viewBox="0 0 16 16">
                    <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6m2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0m4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4m-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664z"/>
                    </svg>
                    <span class="sidebar-icon" style="color:#FFFFFF" data-toggle="tooltip" data-placement="top" title="Barangay Official | Table Name">Barangay Official <br> Table Name</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Role Types</h6>
                        <a class="collapse-item" href="/brgtanod">ANGELICA MAGSINO <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Brgtanod::count() }} </span></a>
                        <a class="collapse-item" href="{{ route('christoper.index') }}">CHRISTOPHER <br> DE LEON <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Christoper::count() }} </span></a> 
                        <a class="collapse-item" href="{{ route('gueco.index') }}">GLEN GUECO <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Gueco::count() }} </span></a> 
                        <a class="collapse-item" href="{{ route('daniel.index') }}">DANIEL AGUSTIN <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Daniel::count() }} </span></a> 
                        <a class="collapse-item" href="{{ route('manalang.index') }}">CRISTINA MANALANG <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Manalang::count() }} </span></a> 
                        <a class="collapse-item" href="{{ route('carl.index') }}">CARL ARBIE DAVID <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Carl::count() }} </span></a> 
                        <a class="collapse-item" href="{{ route('erwin.index') }}">ERWIN MACABANTI <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Erwin::count() }} </span></a>
                        <a class="collapse-item" href="{{ route('karen.index') }}">KAREN ADRIANO <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Karen::count() }} </span></a> 
                        <a class="collapse-item" href="#">JOJO GALANG</a>
                        <a class="collapse-item" href="{{ route('abel.index') }}">ABEL MANLAPAZ <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Abel::count() }} </span></a> 
                    </div>
                </div>
            </li>


            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="bi bi-filetype-doc" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M14 4.5V14a2 2 0 0 1-2 2v-1a1 1 0 0 0 1-1V4.5h-2A1.5 1.5 0 0 1 9.5 3V1H4a1 1 0 0 0-1 1v9H2V2a2 2 0 0 1 2-2h5.5zm-7.839 9.166v.522c0 .256-.039.47-.117.641a.861.861 0 0 1-.322.387.877.877 0 0 1-.469.126.883.883 0 0 1-.471-.126.868.868 0 0 1-.32-.386 1.55 1.55 0 0 1-.117-.642v-.522c0-.257.04-.471.117-.641a.868.868 0 0 1 .32-.387.868.868 0 0 1 .471-.129c.176 0 .332.043.469.13a.861.861 0 0 1 .322.386c.078.17.117.384.117.641Zm.803.519v-.513c0-.377-.068-.7-.205-.972a1.46 1.46 0 0 0-.589-.63c-.254-.147-.56-.22-.917-.22-.355 0-.662.073-.92.22a1.441 1.441 0 0 0-.589.627c-.136.271-.205.596-.205.975v.513c0 .375.069.7.205.973.137.271.333.48.59.627.257.144.564.216.92.216.357 0 .662-.072.916-.216.256-.147.452-.356.59-.627.136-.274.204-.598.204-.973ZM0 11.926v4h1.459c.402 0 .735-.08.999-.238a1.45 1.45 0 0 0 .595-.689c.13-.3.196-.662.196-1.084 0-.42-.065-.778-.196-1.075a1.426 1.426 0 0 0-.59-.68c-.263-.156-.598-.234-1.004-.234H0Zm.791.645h.563c.248 0 .45.05.609.152a.89.89 0 0 1 .354.454c.079.201.118.452.118.753a2.3 2.3 0 0 1-.068.592 1.141 1.141 0 0 1-.196.422.8.8 0 0 1-.334.252 1.298 1.298 0 0 1-.483.082H.79V12.57Zm7.422.483a1.732 1.732 0 0 0-.103.633v.495c0 .246.034.455.103.627a.834.834 0 0 0 .298.393.845.845 0 0 0 .478.131.868.868 0 0 0 .401-.088.699.699 0 0 0 .273-.248.8.8 0 0 0 .117-.364h.765v.076a1.268 1.268 0 0 1-.226.674c-.137.194-.32.345-.55.454a1.81 1.81 0 0 1-.786.164c-.36 0-.664-.072-.914-.216a1.424 1.424 0 0 1-.571-.627c-.13-.272-.194-.597-.194-.976v-.498c0-.379.066-.705.197-.978.13-.274.321-.485.571-.633.252-.149.556-.223.911-.223.219 0 .421.032.607.097.187.062.35.153.489.272a1.326 1.326 0 0 1 .466.964v.073H9.78a.85.85 0 0 0-.12-.38.7.7 0 0 0-.273-.261.802.802 0 0 0-.398-.097.814.814 0 0 0-.475.138.868.868 0 0 0-.301.398Z"/>
                    </svg>
                    <span class="sidebar-icon" style="color:#FFFFFF" data-toggle="tooltip" data-placement="top" title="Document Table">Document Table</span>
                </a>
                <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Baranagay Documents:</h6>
                        <a class="collapse-item" href="{{route('certification.index')}}" data-toggle="tooltip" data-placement="top" title="baranagay Indigency">Barangay Indigency <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Certification::count() }} </span></a> 
                        <a class="collapse-item" href="{{route('barangay_clearances.index')}}" data-toggle="tooltip" data-placement="top" title="Barangay Clearance">Barangay Clearance <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\BarangayClearance::count() }} </span></a> 
                        <a class="collapse-item" href="{{route('residence.index')}}" data-toggle="tooltip" data-placement="top" title="baranagay Indigency">Barangay Residence <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Residence::count() }} </span></a>
                        <a class="collapse-item" href="{{route('barangay-clearance-id.index')}}" data-toggle="tooltip" data-placement="top" title="Barangay ID">Barangay ID <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Barangay_ids::count() }} </span></a>  
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#kagawadPosts" aria-expanded="true" aria-controls="kagawadPosts">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="bi bi-megaphone" viewBox="0 0 16 16">
                    <path d="M13 2.5a1.5 1.5 0 0 1 3 0v11a1.5 1.5 0 0 1-3 0v-.214c-2.162-1.241-4.49-1.843-6.912-2.083l.405 2.712A1 1 0 0 1 5.51 15.1h-.548a1 1 0 0 1-.916-.599l-1.85-3.49a68.14 68.14 0 0 0-.202-.003A2.014 2.014 0 0 1 0 9V7a2.02 2.02 0 0 1 1.992-2.013 74.663 74.663 0 0 0 2.483-.075c3.043-.154 6.148-.849 8.525-2.199zm1 0v11a.5.5 0 0 0 1 0v-11a.5.5 0 0 0-1 0m-1 1.35c-2.344 1.205-5.209 1.842-8 2.033v4.233c.18.01.359.022.537.036 2.568.189 5.093.744 7.463 1.993V3.85zm-9 6.215v-4.13a95.09 95.09 0 0 1-1.992.052A1.02 1.02 0 0 0 1 7v2c0 .55.448 1.002 1.006 1.009A60.49 60.49 0 0 1 4 10.065m-.657.975 1.609 3.037.01.024h.548l-.002-.014-.443-2.966a68.019 68.019 0 0 0-1.722-.082z"/>
                    </svg>
                    <span class="sidebar-icon" style="color:#FFFFFF" data-toggle="tooltip" data-placement="top" title="Council Post Table">Council Post Table</span>
                </a>
                <div id="kagawadPosts" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Baranagay Posts:</h6>
                        <a class="collapse-item" href="/data10" data-toggle="tooltip" data-placement="top" title="DANILO DE LEON">DANILO DE LEON</a> 
                        <a class="collapse-item" href="/data2" data-toggle="tooltip" data-placement="top" title="ANGELICA MAGSINO">ANGELICA MAGSINO</a> 
                        <a class="collapse-item" href="/data" data-toggle="tooltip" data-placement="top" title="CHRISTOPER DE LEON">CHRISTOPER DE LEON</a> 
                        <a class="collapse-item" href="/data3" data-toggle="tooltip" data-placement="top" title="GLEN GUECO">GLEN GUECO</a> 
                        <a class="collapse-item" href="/data4" data-toggle="tooltip" data-placement="top" title="DANIEL AGUSTIN">DANIEL AGUSTIN</a> 
                        <a class="collapse-item" href="/data5" data-toggle="tooltip" data-placement="top" title="CHRISTINA MANALANG">CHRISTINA MANALANG</a>
                        <a class="collapse-item" href="/data6" data-toggle="tooltip" data-placement="top" title="CARL ARBIE DAVID">CARL ARBIE DAVID</a>  
                        <a class="collapse-item" href="/data7" data-toggle="tooltip" data-placement="top" title="ERWIN MACABANTI">ERWIN MACABANTI</a>  
                        <a class="collapse-item" href="/data8" data-toggle="tooltip" data-placement="top" title="KAREN ADRIANO">KAREN ADRIANO</a>
                        <a class="collapse-item" href="/data11" data-toggle="tooltip" data-placement="top" title="JOJO GALANG">JOJO GALANG</a>  
                        <a class="collapse-item" href="/data9" data-toggle="tooltip" data-placement="top" title="ABEL MANLAPAZ">ABEL MANLAPAZ</a>  
  
                    </div>
                </div>
            </li>




      <!-- <div id="collapseThree" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
              <h6 class="collapse-header">Announcement List</h6>
              <a class="collapse-item" href="/data">News Announcement</a>
              <a class="collapse-item" href="#">Add 1</a>
          </div>
      </div>
  </li> -->


            
  <li class="nav-item">
              <a class="nav-link" href="{{ route('activity/log') }}">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="bi bi-clock-history" viewBox="0 0 16 16">
                <path d="M8.515 1.019A7 7 0 0 0 8 1V0a8 8 0 0 1 .589.022zm2.004.45a7.003 7.003 0 0 0-.985-.299l.219-.976c.383.086.76.2 1.126.342zm1.37.71a7.01 7.01 0 0 0-.439-.27l.493-.87a8.025 8.025 0 0 1 .979.654l-.615.789a6.996 6.996 0 0 0-.418-.302zm1.834 1.79a6.99 6.99 0 0 0-.653-.796l.724-.69c.27.285.52.59.747.91l-.818.576zm.744 1.352a7.08 7.08 0 0 0-.214-.468l.893-.45a7.976 7.976 0 0 1 .45 1.088l-.95.313a7.023 7.023 0 0 0-.179-.483m.53 2.507a6.991 6.991 0 0 0-.1-1.025l.985-.17c.067.386.106.778.116 1.17l-1 .025zm-.131 1.538c.033-.17.06-.339.081-.51l.993.123a7.957 7.957 0 0 1-.23 1.155l-.964-.267c.046-.165.086-.332.12-.501zm-.952 2.379c.184-.29.346-.594.486-.908l.914.405c-.16.36-.345.706-.555 1.038l-.845-.535m-.964 1.205c.122-.122.239-.248.35-.378l.758.653a8.073 8.073 0 0 1-.401.432l-.707-.707z"/>
                <path d="M8 1a7 7 0 1 0 4.95 11.95l.707.707A8.001 8.001 0 1 1 8 0z"/>
                <path d="M7.5 3a.5.5 0 0 1 .5.5v5.21l3.248 1.856a.5.5 0 0 1-.496.868l-3.5-2A.5.5 0 0 1 7 9V3.5a.5.5 0 0 1 .5-.5"/>
            </svg>
                <span class="sidebar-icon" style="color:#FFFFFF" data-toggle="tooltip" data-placement="top" title="Activity Log">Activity Log</span></a>
            </li>




  <!-- Divider -->
  <hr class="sidebar-divider d-none d-md-block">
  
  <!-- Sidebar Toggler (Sidebar) -->
  <div class="text-center d-none d-md-inline">
    <button class="rounded-circle border-0" id="sidebarToggle"></button>
  </div>
  

</ul>
@endif

  <!---------------------------------------------------------(Staff) ---------------------------------------------------------------------------->

  @if (auth()->check() && auth()->user()->role == 'Staff')

<ul class="navbar-nav sidebar" style="background: #8b0000" id="accordionSidebar">
    
  <!-- Sidebar - Brand -->
  <center><a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{route('dashboard')}}">
    <div class="sidebar-brand-icon">
    <img class="sidebar-logo" src="{{URL::to('admin_assets/img/bgy-ID-img/tabun.png')}}" alt="Left Logo">
    </div>
    <div class="sidebar-brand-text mx-3"><sup></sup></div>
  </a><br></center>
  
  <!-- Divider -->
  <hr class="sidebar-divider my-0">
  
  <!-- Nav Item - Dashboard -->
  <li class="nav-item">
    <a class="nav-link" href="{{ route('dashboard') }}">
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="bi bi-window" viewBox="0 0 16 16">
    <path d="M2.5 4a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1m2-.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0m1 .5a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1"/>
    <path d="M2 1a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V3a2 2 0 0 0-2-2zm13 2v2H1V3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1M2 14a1 1 0 0 1-1-1V6h14v7a1 1 0 0 1-1 1z"/>
    </svg>
      <span class="sidebar-icon" style="color:#FFFFFF" data-toggle="tooltip" data-placement="top" title="Dashboard">Dashboard</span></a>
  </li>



  <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="bi bi-filetype-doc" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M14 4.5V14a2 2 0 0 1-2 2v-1a1 1 0 0 0 1-1V4.5h-2A1.5 1.5 0 0 1 9.5 3V1H4a1 1 0 0 0-1 1v9H2V2a2 2 0 0 1 2-2h5.5zm-7.839 9.166v.522c0 .256-.039.47-.117.641a.861.861 0 0 1-.322.387.877.877 0 0 1-.469.126.883.883 0 0 1-.471-.126.868.868 0 0 1-.32-.386 1.55 1.55 0 0 1-.117-.642v-.522c0-.257.04-.471.117-.641a.868.868 0 0 1 .32-.387.868.868 0 0 1 .471-.129c.176 0 .332.043.469.13a.861.861 0 0 1 .322.386c.078.17.117.384.117.641Zm.803.519v-.513c0-.377-.068-.7-.205-.972a1.46 1.46 0 0 0-.589-.63c-.254-.147-.56-.22-.917-.22-.355 0-.662.073-.92.22a1.441 1.441 0 0 0-.589.627c-.136.271-.205.596-.205.975v.513c0 .375.069.7.205.973.137.271.333.48.59.627.257.144.564.216.92.216.357 0 .662-.072.916-.216.256-.147.452-.356.59-.627.136-.274.204-.598.204-.973ZM0 11.926v4h1.459c.402 0 .735-.08.999-.238a1.45 1.45 0 0 0 .595-.689c.13-.3.196-.662.196-1.084 0-.42-.065-.778-.196-1.075a1.426 1.426 0 0 0-.59-.68c-.263-.156-.598-.234-1.004-.234H0Zm.791.645h.563c.248 0 .45.05.609.152a.89.89 0 0 1 .354.454c.079.201.118.452.118.753a2.3 2.3 0 0 1-.068.592 1.141 1.141 0 0 1-.196.422.8.8 0 0 1-.334.252 1.298 1.298 0 0 1-.483.082H.79V12.57Zm7.422.483a1.732 1.732 0 0 0-.103.633v.495c0 .246.034.455.103.627a.834.834 0 0 0 .298.393.845.845 0 0 0 .478.131.868.868 0 0 0 .401-.088.699.699 0 0 0 .273-.248.8.8 0 0 0 .117-.364h.765v.076a1.268 1.268 0 0 1-.226.674c-.137.194-.32.345-.55.454a1.81 1.81 0 0 1-.786.164c-.36 0-.664-.072-.914-.216a1.424 1.424 0 0 1-.571-.627c-.13-.272-.194-.597-.194-.976v-.498c0-.379.066-.705.197-.978.13-.274.321-.485.571-.633.252-.149.556-.223.911-.223.219 0 .421.032.607.097.187.062.35.153.489.272a1.326 1.326 0 0 1 .466.964v.073H9.78a.85.85 0 0 0-.12-.38.7.7 0 0 0-.273-.261.802.802 0 0 0-.398-.097.814.814 0 0 0-.475.138.868.868 0 0 0-.301.398Z"/>
                    </svg>
                    <span class="sidebar-icon" style="color:#FFFFFF" data-toggle="tooltip" data-placement="top" title="Document Table">Document Table</span>
                </a>
                <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Baranagay Documents:</h6>
                        <a class="collapse-item" href="{{route('certification.index')}}" data-toggle="tooltip" data-placement="top" title="baranagay Indigency">Barangay Indigency <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Certification::count() }} </span></a> 
                        <a class="collapse-item" href="{{route('barangay_clearances.index')}}" data-toggle="tooltip" data-placement="top" title="Barangay Clearance">Barangay Clearance <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\BarangayClearance::count() }} </span></a> 
                        <a class="collapse-item" href="{{route('barangay-clearance-id.index')}}" data-toggle="tooltip" data-placement="top" title="Barangay ID">Barangay ID <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Barangay_Ids::count() }} </span></a> 
                        <a class="collapse-item" href="{{route('residence.index')}}" data-toggle="tooltip" data-placement="top" title="baranagay Indigency">Barangay Residence <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Residence::count() }} </span></a> 
                    </div>
                </div>
            </li>

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">
    
    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
  

</ul>
@endif




  <!---------------------------------------------------------(Kagawad) ---------------------------------------------------------------------------->

  @if (auth()->check() && auth()->user()->role == 'Kagawad')

<ul class="navbar-nav sidebar" style="background: #8b0000" id="accordionSidebar">
    
  <!-- Sidebar - Brand -->
  <center><a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{route('dashboard')}}">
    <div class="sidebar-brand-icon">
    <img class="sidebar-logo" src="{{URL::to('admin_assets/img/bgy-ID-img/tabun.png')}}" alt="Left Logo">
    </div>
    <div class="sidebar-brand-text mx-3"><sup></sup></div>
  </a><br></center>
  
  <!-- Divider -->
  <hr class="sidebar-divider my-0">
  
  <!-- Nav Item - Dashboard -->
  <li class="nav-item">
    <a class="nav-link" href="{{ route('dashboard') }}">
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="bi bi-window" viewBox="0 0 16 16">
    <path d="M2.5 4a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1m2-.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0m1 .5a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1"/>
    <path d="M2 1a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V3a2 2 0 0 0-2-2zm13 2v2H1V3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1M2 14a1 1 0 0 1-1-1V6h14v7a1 1 0 0 1-1 1z"/>
    </svg>
      <span class="sidebar-icon" style="color:#FFFFFF" data-toggle="tooltip" data-placement="top" title="Dashboard">Dashboard</span></a>
  </li>



  <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="bi bi-person" viewBox="0 0 16 16">
                    <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6m2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0m4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4m-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664z"/>
                    </svg>
                    <span class="sidebar-icon" style="color:#FFFFFF" data-toggle="tooltip" data-placement="top" title="Barangay Official | Table Name">Barangay Official <br> Table Name</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Role Types</h6>
                        <a class="collapse-item" href="/brgtanod">ANGELICA MAGSINO <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\brgtanod::count() }} </span></a>
                        <a class="collapse-item" href="{{ route('christoper.index') }}">CHRISTOPHER <br> DE LEON <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Christoper::count() }} </span></a> 
                        <a class="collapse-item" href="{{ route('gueco.index') }}">GLEN GUECO <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Gueco::count() }} </span></a> 
                        <a class="collapse-item" href="{{ route('daniel.index') }}">DANIEL AGUSTIN <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Daniel::count() }} </span></a> 
                        <a class="collapse-item" href="{{ route('manalang.index') }}">CRISTINA MANALANG <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Manalang::count() }} </span></a> 
                        <a class="collapse-item" href="{{ route('carl.index') }}">CARL ARBIE DAVID <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Carl::count() }} </span></a> 
                        <a class="collapse-item" href="{{ route('erwin.index') }}">ERWIN MACABANTI <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Erwin::count() }} </span></a>
                        <a class="collapse-item" href="{{ route('karen.index') }}">KAREN ADRIANO <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Karen::count() }} </span></a> 
                        <a class="collapse-item" href="#">JOJO GALANG</a>
                        <a class="collapse-item" href="{{ route('abel.index') }}">ABEL MANLAPAZ <span class="badge badge-danger badge-counter" id="notification-badge">{{ \App\Models\Abel::count() }} </span></a> 
                    </div>
                </div>
            </li>


    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">
    
    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
  

</ul>
@endif
