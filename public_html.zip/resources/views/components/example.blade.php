<div>
    {{ $slot }}
</div>
