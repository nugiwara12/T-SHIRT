

<?php $__env->startSection('content'); ?>

<link rel="shortcut icon" href="<?php echo e(URL::to('admin_assets/img/title-logo/tabun.png')); ?>">
<link rel="shortcut icon" href="<?php echo e(URL::to('admin_assets/img/title-logo/tabun.png')); ?>" type="image/x-icon">
  
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />

        <!-- Font Awesome icons (free version)-->
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link rel="stylesheet" href="<?php echo e(URL::to('admin_assets/css/danilo.css')); ?>">
    </head>
    <body id="page-top">
        <!-- Navigation
        <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
            <div class="container">
                <a class="navbar-brand" href="#page-top"><img src="assets/img/navbar-logo.svg" alt="..." /></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars ms-1"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav text-uppercase ms-auto py-4 py-lg-0">
                        <li class="nav-item"><a class="nav-link" href="#services">Services</a></li>
                        <li class="nav-item"><a class="nav-link" href="#portfolio">Portfolio</a></li>
                        <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
                        <li class="nav-item"><a class="nav-link" href="#team">Team</a></li>
                        <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
                    </ul>
                </div>
            </div>
        </nav> -->
        <!-- Masthead-->
        <header class="masthead">
        <div class="container"><br><br><br><br><br><br><br><br><br>
                <div class="masthead-subheading">Kapitan <br> Danilo De leon </div>
                <!-- <div class="masthead-heading text-uppercase">It's Nice To Meet You</div> -->
                <a class="btn btn-primary btn-xl text-white" href="#services">Tell Me More</a>
            </div>
        </header>
        <!-- Services-->
            <section class="page-section" id="services">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Services</h2>
                    <h3 class="section-subheading text-muted">Barangays play a role in maintaining public safety and order. Barangay tanods (community volunteers) may assist in crime prevention, disaster response, and ensuring peace and order within the community.</h3>
                </div>
                <div class="row text-center">
                    <div class="col-md-4">
                        <span class="fa-stack fa-4x">
                            <i class="fas fa-circle fa-stack-2x text-danger"></i>
                            <i class="fa fa-credit-card-alt fa-stack-1x fa-inverse"></i>
                        </span>
                        <h4 class="my-3">Issuance of Barangay Clearance</h4>
                        <p class="text-muted" >Barangays often issue barangay clearances, which certify that a person is a resident of the barangay and is of good moral character. This document may be required for various purposes, such as employment, business permits, and other transactions.</p>
                    </div>
                    <div class="col-md-4">
                        <span class="fa-stack fa-4x">
                            <i class="fas fa-circle fa-stack-2x text-danger"></i>
                            <i class="fa fa-medkit fa-stack-1x fa-inverse"></i>
                        </span>
                        <h4 class="my-3">Health Services</h4>
                        <p class="text-muted">Barangays may provide basic health services such as health centers, vaccination programs, and community health education. They may also collaborate with local health authorities to address public health concerns.</p>
                    </div>
                    <div class="col-md-4">
                        <span class="fa-stack fa-4x">
                            <i class="fas fa-circle fa-stack-2x text-danger"></i>
                            <i class="fa fa-ambulance fa-stack-1x fa-inverse"></i>
                        </span>
                        <h4 class="my-3">Social Services</h4>
                        <p class="text-muted">Barangays may offer social welfare services, including assistance to indigent residents, support for senior citizens, and programs for youth development. Community Programs and Events:</p>
                    </div>
                </div>
            </div>
        </section>
        <!-- Portfolio Grid-->

        
            <section id="blog" style="background-color:#8B0000;;" id="portfolio">
            <div class="text-center">
                <h2 class="section-heading text-uppercase" style="color: white;">Punong Barangay Portfolio</h2>
                <h3 class="section" style="color: white;font-style: italic; font-size: 16px;">Dream it, plan it, do it.</h3>
            </div>
            <div class="container col-xxl-10 py-5">
                <div class="row">

                    <?php $__currentLoopData = $deleons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 mb-4">
                            <a href="/deleonDetail/<?php echo e($item->id); ?>" class="text-decoration-none text-dark">
                                <div class="card bg-white border-0">
                                    <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid rounded-4 mb-3"alt="">
                                        <center><h3 class="fw-bold mb-3"><?php echo e($item->title); ?></h3></center>
                                        <center><p><?php echo e($item->created_at->format('F j, Y')); ?></p></center>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        
        </section><br><br><br>


        <!-- magsino-->
        
            <section id="blog" style="background-color:#8B0000;" id="portfolio">
            <div class="text-center">
                    <h2 class="section-heading text-uppercase" style="color: white;">Angelica Magsino Portfolio</h2>
                    <h3 class="section" style="color: white;font-style: italic; font-size: 16px;">Dream it, plan it, do it.</h3>
            </div>
            <div class="container col-xxl-10 py-5">
                <div class="row">

                    <?php $__currentLoopData = $samples; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 mb-4">
                            <a href="/MagsinoDetail/<?php echo e($item->id); ?>" class="text-decoration-none text-dark">
                                <div class="card bg-white border-0">
                                    <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid rounded-4 mb-3"alt="">
                                        <center><h3 class="fw-bold mb-3"><?php echo e($item->title); ?></h3></center>
                                        <center><p><?php echo e($item->created_at->format('F j, Y')); ?></p></center>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        
        </section><br><br><br>


        <!-- dada-->
        
            <section id="blog" style="background-color:#8B0000;" id="portfolio">
            <div class="text-center">
                <h2 class="section-heading text-uppercase" style="color: white;">Christopher De Leon Portfolio</h2>
                <h3 class="section" style="color: white;font-style: italic; font-size: 16px;">Dream it, plan it, do it.</h3>
            </div>
            <div class="container col-xxl-10 py-5">
                <div class="row">

                    <?php $__currentLoopData = $artikels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 mb-4">
                            <a href="/detail/<?php echo e($item->id); ?>" class="text-decoration-none text-dark">
                                <div class="card bg-white border-0">
                                    <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid rounded-4 mb-3"alt="">
                                        <center><h3 class="fw-bold mb-3"><?php echo e($item->title); ?></h3></center>
                                        <center><p><?php echo e($item->created_at->format('F j, Y')); ?></p></center>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        
        </section><br><br><br>

        <!-- Glen-->
        
            <section id="blog" style="background-color:#8B0000;" id="portfolio">
            <div class="text-center">
                <h2 class="section-heading text-uppercase" style="color: white;">Glen Gueco Portfolio</h2>
                <h3 class="section" style="color: white;font-style: italic; font-size: 16px;">Dream it, plan it, do it.</h3>
            </div>
            <div class="container col-xxl-10 py-5">
                <div class="row">

                    <?php $__currentLoopData = $granadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 mb-4">
                            <a href="/glennDetail/<?php echo e($item->id); ?>" class="text-decoration-none text-dark">
                                <div class="card bg-white border-0">
                                    <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid rounded-4 mb-3"alt="">
                                        <center><h3 class="fw-bold mb-3"><?php echo e($item->title); ?></h3></center>
                                        <center><p><?php echo e($item->created_at->format('F j, Y')); ?></p></center>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        
        </section><br><br><br>

        <!-- Agustin-->
        
            <section id="blog" style="background-color:#8B0000;" id="portfolio">
            <div class="text-center">
                <h2 class="section-heading text-uppercase" style="color: white;">Daniel Agustin Portfolio</h2>
                <h3 class="section" style="color: white;font-style: italic; font-size: 16px;">Dream it, plan it, do it.</h3>
            </div>
            <div class="container col-xxl-10 py-5">
                <div class="row">

                    <?php $__currentLoopData = $growens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 mb-4">
                            <a href="/agustinDetail/<?php echo e($item->id); ?>" class="text-decoration-none text-dark">
                                <div class="card bg-white border-0">
                                    <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid rounded-4 mb-3"alt="">
                                        <center><h3 class="fw-bold mb-3"><?php echo e($item->title); ?></h3></center>
                                        <center><p><?php echo e($item->created_at->format('F j, Y')); ?></p></center>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        
        </section><br><br><br>


        <!-- Manalang-->
        
            <section id="blog" style="background-color:#8B0000;" id="portfolio">
            <div class="text-center">
                <h2 class="section-heading text-uppercase" style="color: white;">Christina Manalang Portfolio</h2>
                <h3 class="section" style="color: white;font-style: italic; font-size: 16px;">Dream it, plan it, do it.</h3>
            </div>
            <div class="container col-xxl-10 py-5">
                <div class="row">

                    <?php $__currentLoopData = $christinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 mb-4">
                            <a href="/christinaDetail/<?php echo e($item->id); ?>" class="text-decoration-none text-dark">
                                <div class="card bg-white border-0">
                                    <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid rounded-4 mb-3"alt="">
                                        <center><h3 class="fw-bold mb-3"><?php echo e($item->title); ?></h3></center>
                                        <center><p><?php echo e($item->created_at->format('F j, Y')); ?></p></center>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        
        </section><br><br><br>


        <!-- Arbhie-->
        
            <section id="blog" style="background-color:#8B0000;" id="portfolio">
            <div class="text-center">
                <h2 class="section-heading text-uppercase" style="color: white;">Carl Arbie Portfolio</h2>
                <h3 class="section" style="color: white;font-style: italic; font-size: 16px;">Dream it, plan it, do it.</h3>
            </div>
            <div class="container col-xxl-10 py-5">
                <div class="row">

                    <?php $__currentLoopData = $arvhies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 mb-4">
                            <a href="/arvhieDetail/<?php echo e($item->id); ?>" class="text-decoration-none text-dark">
                                <div class="card bg-white border-0">
                                    <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid rounded-4 mb-3"alt="">
                                        <center><h3 class="fw-bold mb-3"><?php echo e($item->title); ?></h3></center>
                                        <center><p><?php echo e($item->created_at->format('F j, Y')); ?></p></center>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        
        </section><br><br><br>


        <!-- Macabanti-->
        
            <section id="blog" style="background-color:#8B0000;" id="portfolio">
            <div class="text-center">
                <h2 class="section-heading text-uppercase" style="color: white;">Erwin Macabanti Portfolio</h2>
                <h3 class="section" style="color: white;font-style: italic; font-size: 16px;">Dream it, plan it, do it.</h3>
            </div>
            <div class="container col-xxl-10 py-5">
                <div class="row">

                    <?php $__currentLoopData = $macabantis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 mb-4">
                            <a href="/macabantiDetail/<?php echo e($item->id); ?>" class="text-decoration-none text-dark">
                                <div class="card bg-white border-0">
                                    <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid rounded-4 mb-3"alt="">
                                        <center><h3 class="fw-bold mb-3"><?php echo e($item->title); ?></h3></center>
                                        <center><p><?php echo e($item->created_at->format('F j, Y')); ?></p></center>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        
        </section><br><br><br>

        <!-- Galang-->
        
            <section id="blog" style="background-color:#8B0000;" id="portfolio">
            <div class="text-center">
                <h2 class="section-heading text-uppercase" style="color: white;">Jojo Galang Portfolio</h2>
                <h3 class="section" style="color: white;font-style: italic; font-size: 16px;">Dream it, plan it, do it.</h3>
            </div>
            <div class="container col-xxl-10 py-5">
                <div class="row">

                    <?php $__currentLoopData = $galangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 mb-4">
                            <a href="/galangDetail/<?php echo e($item->id); ?>" class="text-decoration-none text-dark">
                                <div class="card bg-white border-0">
                                    <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid rounded-4 mb-3"alt="">
                                        <center><h3 class="fw-bold mb-3"><?php echo e($item->title); ?></h3></center>
                                        <center><p><?php echo e($item->created_at->format('F j, Y')); ?></p></center>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        
        </section><br><br><br>


        <!-- manlapazs-->
        
            <section id="blog" style="background-color:#8B0000;" id="portfolio">
            <div class="text-center">
                <h2 class="section-heading text-uppercase" style="color: white;">Abel Manlapaz Portfolio</h2>
                <h3 class="section" style="color: white;font-style: italic; font-size: 16px;">Dream it, plan it, do it.</h3>
            </div>
            <div class="container col-xxl-10 py-5">
                <div class="row">

                    <?php $__currentLoopData = $manlapazs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 mb-4">
                            <a href="/abelleDetail/<?php echo e($item->id); ?>" class="text-decoration-none text-dark">
                                <div class="card bg-white border-0">
                                    <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid rounded-4 mb-3"alt="">
                                        <center><h3 class="fw-bold mb-3"><?php echo e($item->title); ?></h3></center>
                                        <center><p><?php echo e($item->created_at->format('F j, Y')); ?></p></center>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        
        </section><br><br><br>
        
        

        <!-- About-->
        <section class="page-section" id="about">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">About</h2>
                    <h3 class="section-subheading text-muted">Lorem ipsum dolor sit amet consectetur.</h3>
                </div>
                <ul class="timeline">
                    <li>
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="<?php echo e(asset('admin_assets/img/kagawad/kapDan.png')); ?>" alt="..." /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>2009-2011</h4>
                                <h4 class="subheading">Our Humble Beginnings</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt ut voluptatum eius sapiente, totam reiciendis temporibus qui quibusdam, recusandae sit vero unde, sed, incidunt et ea quo dolore laudantium consectetur!</p></div>
                        </div>
                    </li>
                    <li class="timeline-inverted">
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="<?php echo e(asset('admin_assets/img/kagawad/kapDan.png')); ?>" alt="..." /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>March 2011</h4>
                                <h4 class="subheading">An Agency is Born</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt ut voluptatum eius sapiente, totam reiciendis temporibus qui quibusdam, recusandae sit vero unde, sed, incidunt et ea quo dolore laudantium consectetur!</p></div>
                        </div>
                    </li>
                    <li>
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="<?php echo e(asset('admin_assets/img/kagawad/kapDan.png')); ?>" alt="..." /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>December 2015</h4>
                                <h4 class="subheading">Transition to Full Service</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt ut voluptatum eius sapiente, totam reiciendis temporibus qui quibusdam, recusandae sit vero unde, sed, incidunt et ea quo dolore laudantium consectetur!</p></div>
                        </div>
                    </li>
                    <li class="timeline-inverted">
                        <div class="timeline-image"><img class="rounded-circle img-fluid" src="<?php echo e(asset('admin_assets/img/kagawad/kapDan.png')); ?>" alt="..." /></div>
                        <div class="timeline-panel">
                            <div class="timeline-heading">
                                <h4>July 2020</h4>
                                <h4 class="subheading">Phase Two Expansion</h4>
                            </div>
                            <div class="timeline-body"><p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt ut voluptatum eius sapiente, totam reiciendis temporibus qui quibusdam, recusandae sit vero unde, sed, incidunt et ea quo dolore laudantium consectetur!</p></div>
                        </div>
                    </li>
                    <li class="timeline-inverted">
                        <div class="timeline-image">
                            <h4>
                                Be Part
                                <br />
                                Of Our
                                <br />
                                Story!
                            </h4>
                        </div>
                    </li>
                </ul>
            </div>
        </section>

        <!-- Footer-->

        <footer class="footer py-4">
            <div class="container">
                <div class="row align-items-center">
                <div class="col-lg-4 text-lg-start">Copyright Sarmiento / Mercado; Barangay Tabun</div>
                    <div class="col-lg-4 my-3 my-lg-0">
                        <!-- <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Twitter"><i class="fab fa-twitter"></i></a> -->
                        <a class="btn btn-dark btn-social mx-2" href="https://www.facebook.com/profile.php?id=61556005325787" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-dark btn-social mx-2" href="https://mail.google.com/mail/u/0/#inbox" aria-label="Email"><i class="fas fa-envelope"></i></a>
                        <!-- <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a> -->
                    </div>
                    <div class="col-lg-4 text-lg-end">
                        <a class="link-dark text-decoration-none me-3" href="https://mail.google.com/mail/u/0/#inbox">barangaytabunmabalacat@gmail.com</a>
                    </div>
                </div>
            </div>
        </footer>

        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>


        <script>
            window.addEventListener('DOMContentLoaded', event => {

            // Navbar shrink function
            var navbarShrink = function () {
                const navbarCollapsible = document.body.querySelector('#mainNav');
                if (!navbarCollapsible) {
                    return;
                }
                if (window.scrollY === 0) {
                    navbarCollapsible.classList.remove('navbar-shrink')
                } else {
                    navbarCollapsible.classList.add('navbar-shrink')
                }

            };

            // Shrink the navbar 
            navbarShrink();

            // Shrink the navbar when page is scrolled
            document.addEventListener('scroll', navbarShrink);

            //  Activate Bootstrap scrollspy on the main nav element
            const mainNav = document.body.querySelector('#mainNav');
            if (mainNav) {
                new bootstrap.ScrollSpy(document.body, {
                    target: '#mainNav',
                    rootMargin: '0px 0px -40%',
                });
            };

            // Collapse responsive navbar when toggler is visible
            const navbarToggler = document.body.querySelector('.navbar-toggler');
            const responsiveNavItems = [].slice.call(
                document.querySelectorAll('#navbarResponsive .nav-link')
            );
            responsiveNavItems.map(function (responsiveNavItem) {
                responsiveNavItem.addEventListener('click', () => {
                    if (window.getComputedStyle(navbarToggler).display !== 'none') {
                        navbarToggler.click();
                    }
                });
            });

            });

        </script>

        

        <?php echo $__env->yieldContent('content'); ?>

        
        <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
            crossorigin="anonymous"></script>

        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.20/summernote-bs5.min.js"></script>
        <script>
            $(document).ready(function() {
                $('#summernote').summernote({
                    height: 300,
                });
            });
        </script>


        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous">
        </script>

        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u450856919/domains/balacataccountingoffice.site/public_html/resources/views/deleon.blade.php ENDPATH**/ ?>