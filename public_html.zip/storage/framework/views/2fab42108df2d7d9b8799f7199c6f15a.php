
  
<?php $__env->startSection('title', 'Create Barangay Clearance'); ?>
  
<?php $__env->startSection('contents'); ?>
<link rel="stylesheet" href="<?php echo e(URL::to('admin_assets/css/brgy-clearance-create.css')); ?>">

<form action="<?php echo e(route('barangay_clearances.store')); ?>" method="POST" enctype="multipart/form-data">
        
        <?php if(Session::has('success')): ?>
            <div class="custom-box">
                <div class="alert alert-success" role="alert">
                    <?php echo e(Session::get('success')); ?>

                </div>
            </div>
        <?php endif; ?>
        
        <?php echo csrf_field(); ?>
        <h1>Barangay Clearance</h1>
        <label for="parent">Parent Name:</label>
        <input class="form-control" type="text" name="parent" id="parent" name="parent" value="<?php echo e(old('parent')); ?>" required>
        <br>
        <label for="name">Your Name</label>
        <input class="form-control" type="text" name="name" id="name" name="name" value="<?php echo e(old('name')); ?>" required>
        <br>
        <label for="address">Address:</label>
        <input class="form-control" type="text" name="address" id="address" name="address" value="<?php echo e(old('address')); ?>" required>
        <br>
        <label for="reason">Purpose to use:</label>
        <textarea class="form-control" name="reason" id="reason" required><?php echo e(old('reason')); ?></textarea>
        <br>

        <label for="age">Age:</label>
        <input class="form-control" type="number" id="age" name="age" value="<?php echo e(old('age')); ?>" required min="18" max="200" pattern="[0-9]+">


        <!-- <label for="minor">Select Legal Age:</label>
        <select class="form-control" name="minor" id="minor" required>
            <option value="minor" <?php if(old('minor') == 'minor'): ?> selected <?php endif; ?>>legal Age</option>
        </select>
        <br><br> -->


        <label for="generated_number">Referal Code:</label>
            <input class="form-control" type="text" id="generated_number" name="generated_number" readonly>
            <?php $__errorArgs = ['generated_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;"><?php echo e($message); ?></span><br><br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <button type="button" onclick="generateNumber()">Generate Number</button><br><br>
        

        <button class="botton-submite" type="submit">Submit</button>
    </form>


<script>
    function generateNumber() {
    const generatedNumberInput = document.getElementById('generated_number');

    // Generate a random number or use your logic to generate one
    const randomNumber = Math.floor(Math.random() * 100000) + 1;

    // Fill the generated number into the input field
    generatedNumberInput.value = randomNumber;
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u450856919/domains/balacataccountingoffice.site/public_html/resources/views/barangay_clearances/create.blade.php ENDPATH**/ ?>