
  
<?php $__env->startSection('title', 'Barangay Indigency'); ?>
  
<?php $__env->startSection('contents'); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
   

    <div class="d-flex align-items-center justify-content-between">
        <a href="<?php echo e(route('certification.create')); ?>" class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="Add Barangay Indigency">Add Barangay Clearance</a>
    </div>
    <br>

    <div class="d-flex align-items-center justify-content-between">
        <a href="<?php echo e(route('certification.create3')); ?>" class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="Add Minor Barangay Indigency">Add Minor Barangay Clearance</a>
    </div>

    <hr />
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('success')); ?>

        </div>
    <?php endif; ?>
    <table class="table table-hover" id="example">
        <thead class="table-primary">
            <tr>
                <th>#</th>
                <th>Parent Name</th>
                <th>Address</th>
                <th>Purpose</th>
                <th>Your Name</th>
                <th>Date</th>
                <th>Age</th>
                <th>Minor</th>
                <th>Referal Number</th>
                <th>Action</th>
            </tr>
        </thead>
    <tbody>
            <?php if($certifications->count() > 0): ?>
                <?php $__currentLoopData = $certifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="align-middle"><?php echo e($loop->iteration); ?></td>
                        <td class="align-middle"><?php echo e($rs->mother_name); ?></td>
                        <td class="align-middle"><?php echo e($rs->address); ?></td>
                        <td class="align-middle"><?php echo e($rs->purpose); ?></td>
                        <td class="align-middle"><?php echo e($rs->your_name); ?></td>
                        <td class="align-middle"><?php echo e($rs->date); ?></td>
                        <td class="align-middle"><?php echo e($rs->age); ?></td>
                        <td class="align-middle"><?php echo e($rs->minor); ?></td>
                        <td class="align-middle"><?php echo e($rs->generated_number); ?></td>

                        <td class="align-middle">
                            <div class="btn-group" role="group" aria-label="Basic example">
                                <a href="<?php echo e(route('certification.show', $rs->id)); ?>" type="button" class="btn btn-secondary" data-toggle="tooltip" data-placement="top" title="View Details">Detail</a>
                                <a href="<?php echo e(route('certification.show2.pdf2', ['id' => $rs->id])); ?>" class="btn btn-primary" target="_blank" data-toggle="tooltip" data-placement="top" title="Minor Generate PDF">Minor Generate PDF</a>
                                <a href="<?php echo e(route('certification.edit', $rs->id)); ?>" type="button" class="btn btn-warning" data-toggle="tooltip" data-placement="top" title="Edit">Edit</a>
                                <a href="<?php echo e(route('certification.show.pdf', ['id' => $rs->id])); ?>" class="btn btn-primary" target="_blank" data-toggle="tooltip" data-placement="top" title="Generate PDF">Generate PDF</a>
                                <form action="<?php echo e(route('certification.destroy', $rs->id)); ?>" method="POST" type="button" class="btn btn-danger p-0" onsubmit="return confirm('Delete?')"data-toggle="tooltip" data-placement="top" title="Delete">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger m-0">Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>

            <?php endif; ?>
        </tbody>
    </table>
    <footer>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>
    <script>
         $(document).ready(function() {
            $('#example').DataTable( {
                // dom: 'Bfrtip',
                // buttons: [
                //     'print',
                //     'excel'
                // ]
            } );
        } );
    </script>

    <!-- Include DataTables Buttons extension CSS and JS -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.1.1/css/buttons.dataTables.min.css">
    <script src="https://cdn.datatables.net/buttons/2.1.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.1.1/js/buttons.html5.min.js"></script>

    <!-- Include ExcelJS library for Excel export -->
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/pdfmake.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/vfs_fonts.js"></script>
    </footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u450856919/domains/balacataccountingoffice.site/public_html/resources/views/certification/index.blade.php ENDPATH**/ ?>