

<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link rel="stylesheet" href="<?php echo e(URL::to('admin_assets/css/indexAbout.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::to('admin_assets/css/contact.css')); ?>">
        <!-- <link rel="stylesheet" href="<?php echo e(URL::to('admin_assets/css/welcome.css')); ?>"> -->

        <link rel="shortcut icon" href="<?php echo e(URL::to('admin_assets/img/title-logo/tabun.png')); ?>">
        <link rel="shortcut icon" href="<?php echo e(URL::to('admin_assets/img/title-logo/tabun.png')); ?>" type="image/x-icon">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

    </head>

    <body>
        <!-- Masthead-->
        <header class="masthead">
            <div class="container">
                <div class="masthead-heading text-uppercase">Contact <br> US</div>
            </div>
    </header>
            
        <div class="container mt-5">

        <!-- Success message -->
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>

        <form action="" method="post" action="<?php echo e(route('contact.store')); ?>">

            <?php echo csrf_field(); ?>

            <div class="form-group">
            <label>Name</label>
            <input type="text" class="form-control <?php echo e($errors->has('name') ? 'error' : ''); ?>" name="name" id="name" value="<?php echo e(old('name')); ?>">

            <!-- Error -->
            <?php if($errors->has('name')): ?>
            <div class="error">
                <?php echo e($errors->first('name')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label>Your Email</label>
            <input type="email" class="form-control <?php echo e($errors->has('email') ? 'error' : ''); ?>" name="email" id="email" value="<?php echo e(old('email')); ?>">

            <?php if($errors->has('email')): ?>
            <div class="error">
                <?php echo e($errors->first('email')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label>Phone</label>
            <input type="text" class="form-control <?php echo e($errors->has('phone') ? 'error' : ''); ?>" name="phone" id="phone" value="<?php echo e(old('phone')); ?>">

            <?php if($errors->has('phone')): ?>
            <div class="error">
                <?php echo e($errors->first('phone')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label>Message</label>
            <textarea class="form-control <?php echo e($errors->has('message') ? 'error' : ''); ?>" name="message" id="message" rows="4"><?php echo e(old('message')); ?></textarea>

            <?php if($errors->has('message')): ?>
            <div class="error">
                <?php echo e($errors->first('message')); ?>

            </div>
            <?php endif; ?>
        </div>

            <input type="submit" name="send" value="Submit" class="btn btn-dark btn-block">
            </form><br><br><br><br>
        </div>
</body>
</html>


<!-- Footer-->

<footer class="footer py-4">
            <div class="container">
                <div class="row align-items-center">
                <div class="col-lg-4 text-lg-start">Copyright Sarmiento / Mercado; Barangay Tabun</div>
                    <div class="col-lg-4 my-3 my-lg-0">
                        <!-- <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="Twitter"><i class="fab fa-twitter"></i></a> -->
                        <a class="btn btn-dark btn-social mx-2" href="https://www.facebook.com/profile.php?id=61556005325787" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-dark btn-social mx-2" href="https://mail.google.com/mail/u/0/#inbox" aria-label="Email"><i class="fas fa-envelope"></i></a>
                        <!-- <a class="btn btn-dark btn-social mx-2" href="#!" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a> -->
                    </div>
                    <div class="col-lg-4 text-lg-end">
                        <a class="link-dark text-decoration-none me-3" href="https://mail.google.com/mail/u/0/#inbox">barangaytabunmabalacat@gmail.com</a>
                    </div>
                </div>
            </div>
        </footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u450856919/domains/balacataccountingoffice.site/public_html/resources/views/contact.blade.php ENDPATH**/ ?>