

<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Baranagay Tabun</title>


    <link rel="shortcut icon" href="<?php echo e(URL::to('admin_assets/img/title-logo/tabun.png')); ?>">
    <link rel="shortcut icon" href="<?php echo e(URL::to('admin_assets/img/title-logo/tabun.png')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(URL::to('admin_assets/css/brgy-clearance-create1.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11">

</head>
<body>


    <div class="residence">
        <!-- Your existing content -->

        <!-- Form section -->
        <div class="residence">
        <!-- Your existing content -->

        <!-- Form section -->
        <form action="<?php echo e(route('residence.store5')); ?>" method="POST" id="myForm">

            <?php if(Session::has('success')): ?>
                <div class="custom-box">
                    <div class="alert alert-success" role="alert">
                        <?php echo e(Session::get('success')); ?>

                    </div>
                </div>
            <?php endif; ?>
            
            <?php echo csrf_field(); ?>
            <center><h1>Barangay Residence</h1></center>
            <br>
            <label for="mother_name">Parent Name:</label>
            <input class="form-control" type="text" id="mother_name" name="mother_name" value="<?php echo e(old('mother_name')); ?>" required>
            <?php $__errorArgs = ['mother_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label for="address">Address:</label>
            <input class="form-control" type="text" id="address" name="address" value="<?php echo e(old('address')); ?>" required>
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label for="purpose">Purpose to use:</label>
            <input class="form-control" type="text" id="purpose" name="purpose" value="<?php echo e(old('purpose')); ?>" required>
            <?php $__errorArgs = ['purpose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label for="your_name">Name of Chidlren::</label>
            <input class="form-control" type="text" id="your_name" name="your_name" value="<?php echo e(old('your_name')); ?>" required>
            <?php $__errorArgs = ['your_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label for="gender" style="color: black;">Son or Doughter?:</label>
            <select class="form-control <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gender" id="gender" required ="gender">
                <option value="" disabled <?php echo e(old('gender') ? '' : 'selected'); ?>>Select Type</option>
                <option value="Son" <?php echo e(old('gender') == 'Son' ? 'selected' : ''); ?>>Son</option>
                <option value="Duaghter" <?php echo e(old('gender') == 'Duaghter' ? 'selected' : ''); ?>>Duaghter</option>
            </select>

                <br>


            <label for="date_start">Date of Resident:</label>
            <input class="form-control" type="date" id="date_start" name="date_start" value="<?php echo e(old('date_start')); ?>" required>
            <?php $__errorArgs = ['date_start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label for="age">Age:</label>
            <input class="form-control" type="number" id="age" name="age" value="<?php echo e(old('age')); ?>" required min="1" max="17" pattern="[0-9]+">
            <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>



            <label for="date_of_birth">Date of Birth:</label>
            <input class="form-control" type="date" id="date_of_birth" name="date_of_birth" value="<?php echo e(old('date_of_birth')); ?>" required>
            <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label for="minor">Select Minor:</label>
            <select class="form-control" name="minor" id="minor" required>
                <option value="minor" <?php if(old('minor') == 'minor'): ?> selected <?php endif; ?>>Minor</option>
            </select>
            <?php $__errorArgs = ['minor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;"><?php echo e($message); ?></span><br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br>

            <!-- Your HTML code -->
            <label for="generated_number">Referral Code:</label>
            <input class="form-control" type="text" id="generated_number" name="generated_number" readonly>
            <?php $__errorArgs = ['generated_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: red;"><?php echo e($message); ?></span><br><br>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <button type="button" onclick="generateNumber()">Generate Number</button><br><br>

            <button class="botton-submite" type="button" onclick="confirmSubmit()">Submit</button>
        </form>
    </div>




<!-- For Submite Sweet-Alert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function confirmSubmit() {
        Swal.fire({
            title: 'Reminder!',
            text: 'MUST BE ACOMPANED BY PARENT OR GUARDIAN PRIOR TO RELEASE YOUR DOCUMENT.', 
            icon: 'success',
            showCancelButton: true,
            confirmButtonText: 'Yes, submit it!',
            cancelButtonText: 'No, cancel!',
        }).then((result) => {
            if (result.isConfirmed) {
                // If the user clicks "Yes," submit the form
                document.getElementById('myForm').submit();
            }
        });
    }

    // Add a function to generate the number (assuming you have this function)
    function generateNumber() {
        // Your existing generateNumber function logic
    }
</script>



<!-- Generate Code JavaScript code -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
    function generateNumber() {
        // Display SweetAlert confirmation message
        Swal.fire({
            title: 'Reminders',
            text: 'Please screen shot the referal code to get the documents in Barangay Tabun. Thank you',
            icon: 'info',
            showCancelButton: true,
            confirmButtonText: 'Yes, generate it!',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            // Check if the user clicked the "Generate it!" button
            if (result.isConfirmed) {
                const generatedNumberInput = document.getElementById('generated_number');

                // Generate a random number or use your logic to generate one
                const randomNumber = Math.floor(Math.random() * 100000) + 1;

                // Fill the generated number into the input field
                generatedNumberInput.value = randomNumber;

                // Display SweetAlert success message
                Swal.fire({
                    title: 'Barangay Tabun Referral Code !',
                    text: 'Your referral code is: ' + randomNumber,
                    icon: 'success',
                    confirmButtonText: 'OK'
                });
            }
        });
    }
</script>
</body>

</html>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u450856919/domains/balacataccountingoffice.site/public_html/resources/views/residence/create4.blade.php ENDPATH**/ ?>