<!DOCTYPE html>
<html lang="en">

<head>
    <title>Baranagay Tabun</title>
    <link href="<?php echo e(asset('admin_assets/css/sb-admin-2.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin_assets/css/forgot-password.css')); ?>" rel="stylesheet">
    <link rel="shortcut icon" href="<?php echo e(URL::to('admin_assets/img/title-logo/tabun.png')); ?>">
    <link rel="shortcut icon" href="<?php echo e(URL::to('admin_assets/img/title-logo/tabun.png')); ?>" type="image/x-icon">
</head>

<body>



<body class="bg-gradient-primary" style="background-image: url('admin_assets/img/wallpaper/baragayTabun.png'); background-size: cover; background-repeat: no-repeat; background-attachment: fixed;">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-xl-6 col-lg-4 col-md-4"> <!-- Adjust the column width as needed -->
        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <div class="row">
              <div class="col-lg-12">
                <div class="p-5">
                  <div class="text-center">
                  <img src="admin_assets/img/title-logo/tabun.png" alt="logo" width="100" height="50%">
                    <h1 class="h4 text-gray-900 mb-4">Forgot-password</h1>
                    <p>Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one.</p>
                  </div>
                  <form class="user" method="POST" action="/new-password">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($err); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                                <?php if(isset($error)): ?>
                                    <div class="alert alert-danger" role="alert"><?php echo e($error); ?></div>
                                <?php endif; ?>
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <input value="<?php echo e(old('email')); ?>" type="email" class="form-control form-control-user"
                                        id="exampleInputEmail" aria-describedby="emailHelp"
                                        placeholder="Enter Email Address..." name="email" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> style="border: 3px solid #F19E9EFF;" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                                </div>
                                <input type="submit" class="btn btn-primary btn-user btn-block" value="Send OTP">
                            </form>




    <!-- <div class="container">
        <div class="card o-hidden border-0 shadow-lg">
            <div class="card-body p-0">
                <div class="row">
                    <div class="col-lg-2 d-none d-lg-block"></div>
                    <div class="col-lg-6">
                        <div class="card-content p-5">
                            <div class="text-center">
                                <h1 class="title">Forgot Your Password?</h1>
                            </div>
                            <form class="user" method="POST" action="/new-password">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($err); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                                <?php if(isset($error)): ?>
                                    <div class="alert alert-danger" role="alert"><?php echo e($error); ?></div>
                                <?php endif; ?>
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <input value="<?php echo e(old('email')); ?>" type="email" class="form-control form-control-user"
                                        id="exampleInputEmail" aria-describedby="emailHelp"
                                        placeholder="Enter Email Address..." name="email" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>style="border: 3px solid #F19E9EFF;" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                                </div>
                                <input type="submit" class="btn btn-primary btn-user btn-block" value="Send OTP">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->

</body>

</html>
<?php /**PATH /home/u450856919/domains/balacataccountingoffice.site/public_html/resources/views/forgot-password.blade.php ENDPATH**/ ?>